# mu (Memory Unit)

A blazing-fast CLI tool that creates a deterministic map of your codebase for AI context injection.

## Installation

```bash
cd mu
cargo build --release
```

Binary will be at `target/release/mu.exe` (Windows) or `target/release/mu` (Unix).

## Usage

```bash
# Generate context.xml from current directory
mu

# Watch mode - auto-regenerates on file changes
mu watch
```

## Output

Generates `context.xml` in the current directory:

```xml
<project_map>
<file path="src/main.rs">
[file content]
</file>
<file path="README.md">
[file content]
</file>
</project_map>
```

## Features

- Deterministic output (sorted paths)
- Auto-ignores junk: `.git`, `node_modules`, `target`, `dist`, `build`, `__pycache__`, etc.
- Skips binary files (null-byte detection)
- Proper XML escaping
- Watch mode with 200ms debounce
- UTF-8 text files only

## License

MIT
