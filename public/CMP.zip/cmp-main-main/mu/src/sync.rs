use crate::memory::{hash_content, FileEntry, Memory};
use crate::scanner::scan_files;
use anyhow::Result;
use std::fs;
use std::path::Path;
use std::time::SystemTime;

pub struct SyncService {
    root: std::path::PathBuf,
}

impl SyncService {
    pub fn new(root: &Path) -> Self {
        Self {
            root: root.to_path_buf(),
        }
    }

    /// Full scan - builds memory from scratch
    pub fn full_scan(&self) -> Result<Memory> {
        let mut memory = Memory::default();
        memory.version = 1;

        let files = scan_files(&self.root)?;
        let entries = self.parse_files(&files);
        memory.patch(entries);

        Ok(memory)
    }

    /// Incremental sync - only updates dirty files
    pub fn incremental_sync(&self, mut memory: Memory) -> Result<Memory> {
        let files = scan_files(&self.root)?;
        
        // Get file paths with modification times
        let current: Vec<_> = files
            .iter()
            .filter_map(|p| {
                let modified = fs::metadata(p)
                    .and_then(|m| m.modified())
                    .ok()?
                    .duration_since(SystemTime::UNIX_EPOCH)
                    .ok()?
                    .as_secs();
                Some((p.clone(), modified))
            })
            .collect();

        // Find dirty files
        let dirty = memory.get_dirty_files(&current);
        
        if dirty.is_empty() {
            println!("✓ No changes detected");
            return Ok(memory);
        }

        println!("⟳ Syncing {} changed file(s)...", dirty.len());
        
        // Parse only dirty files
        let updates = self.parse_files(&dirty);
        memory.patch(updates);

        // Remove deleted files
        let existing: Vec<String> = current
            .iter()
            .map(|(p, _)| {
                p.strip_prefix(&self.root)
                    .unwrap_or(p)
                    .to_string_lossy()
                    .replace('\\', "/")
            })
            .collect();
        memory.remove_deleted(&existing);

        Ok(memory)
    }

    fn parse_files(&self, files: &[std::path::PathBuf]) -> Vec<FileEntry> {
        files
            .iter()
            .filter_map(|path| {
                let content = read_text_file(path)?;
                let modified = fs::metadata(path)
                    .and_then(|m| m.modified())
                    .ok()?
                    .duration_since(SystemTime::UNIX_EPOCH)
                    .ok()?
                    .as_secs();

                let rel_path = path
                    .strip_prefix(&self.root)
                    .unwrap_or(path)
                    .to_string_lossy()
                    .replace('\\', "/");

                Some(FileEntry {
                    path: rel_path,
                    content: content.clone(),
                    modified,
                    hash: hash_content(&content),
                })
            })
            .collect()
    }
}

fn read_text_file(path: &Path) -> Option<String> {
    let content = fs::read(path).ok()?;
    let check_len = content.len().min(8192);
    if content[..check_len].contains(&0) {
        return None;
    }
    String::from_utf8(content).ok()
}
