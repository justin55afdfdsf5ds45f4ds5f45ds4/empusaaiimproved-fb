use anyhow::Result;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use walkdir::WalkDir;

pub const IGNORED_DIRS: &[&str] = &[
    "node_modules",
    ".git",
    "target",
    "dist",
    "vendor",
    ".next",
    "build",
    ".env",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "coverage",
    ".nuxt",
];

// SECURITY: Hard-blocked files - NEVER include these
pub const IGNORED_FILES: &[&str] = &[
    // System
    ".DS_Store",
    // Secrets & credentials
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
    "id_rsa",
    "id_rsa.pub",
    "id_ed25519",
    "id_ed25519.pub",
    "id_dsa",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "secrets.yaml",
    "secrets.yml",
    "secrets.json",
    ".npmrc",
    ".pypirc",
    "credentials",
    "credentials.json",
    "service-account.json",
    // Output files
    "context.xml",
    "context.json",
    "context.md",
    ".mu_memory.json",
];

// Patterns for extension-based blocking
pub const BLOCKED_EXTENSIONS: &[&str] = &[
    "pem", "key", "p12", "pfx", "jks", "keystore",
];

pub const BLOCKED_PATTERNS: &[&str] = &[
    "id_rsa", "id_dsa", "id_ed25519", "id_ecdsa",
    "aws_access", "aws_secret", "credentials",
];

pub fn scan_files(root: &Path) -> Result<Vec<PathBuf>> {
    let ignored_dirs: HashSet<&str> = IGNORED_DIRS.iter().copied().collect();
    let ignored_files: HashSet<&str> = IGNORED_FILES.iter().copied().collect();

    let mut entries: Vec<PathBuf> = WalkDir::new(root)
        .into_iter()
        .filter_entry(|e| !should_skip_dir(e, &ignored_dirs))
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .filter(|e| !is_blocked_file(e.path(), &ignored_files))
        .map(|e| e.into_path())
        .collect();

    entries.sort();
    Ok(entries)
}

fn is_blocked_file(path: &Path, ignored_files: &HashSet<&str>) -> bool {
    let filename = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
    
    // Direct filename match
    if ignored_files.contains(filename) {
        return true;
    }
    
    // Extension-based blocking
    if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
        if BLOCKED_EXTENSIONS.contains(&ext) {
            return true;
        }
    }
    
    // Pattern-based blocking (contains check)
    let lower = filename.to_lowercase();
    for pattern in BLOCKED_PATTERNS {
        if lower.contains(pattern) {
            return true;
        }
    }
    
    false
}

fn should_skip_dir(entry: &walkdir::DirEntry, ignored: &HashSet<&str>) -> bool {
    entry
        .file_name()
        .to_str()
        .map(|s| ignored.contains(s))
        .unwrap_or(false)
}

pub fn is_ignored_path(path: &Path) -> bool {
    path.components().any(|c| {
        c.as_os_str()
            .to_str()
            .map(|s| IGNORED_DIRS.contains(&s) || IGNORED_FILES.contains(&s))
            .unwrap_or(false)
    })
}
