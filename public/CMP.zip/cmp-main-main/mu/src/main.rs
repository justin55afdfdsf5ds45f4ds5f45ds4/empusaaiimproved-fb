mod formatter;
mod memory;
mod scanner;
mod sync;

use anyhow::{Context, Result};
use arboard::Clipboard;
use clap::{Parser, Subcommand, ValueEnum};
use formatter::{estimate_tokens, format_token_count, get_formatter, OutputTarget};
use memory::Memory;
use notify_debouncer_mini::{new_debouncer, notify::RecursiveMode, DebouncedEventKind};
use scanner::is_ignored_path;
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::Path;
use std::sync::mpsc::channel;
use std::time::Duration;
use sync::SyncService;

#[derive(Parser)]
#[command(name = "mu")]
#[command(about = "Memory Unit - Deterministic codebase mapper for AI context injection")]
#[command(version)]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,

    /// Output format target
    #[arg(short, long, default_value = "claude")]
    target: Target,

    /// Copy output to clipboard automatically
    #[arg(short, long)]
    copy: bool,
}

#[derive(Clone, ValueEnum, Default)]
enum Target {
    /// Raw JSON dump
    Raw,
    /// XML optimized for Claude/Anthropic caching
    #[default]
    Claude,
    /// Markdown for Cursor chat/rules
    Cursor,
}

impl From<Target> for OutputTarget {
    fn from(t: Target) -> Self {
        match t {
            Target::Raw => OutputTarget::Raw,
            Target::Claude => OutputTarget::Claude,
            Target::Cursor => OutputTarget::Cursor,
        }
    }
}

#[derive(Subcommand)]
enum Commands {
    /// Watch for file changes and auto-regenerate context
    Watch,
    /// Incremental sync - only update changed files
    Sync,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let root = std::env::current_dir().context("Failed to get current directory")?;
    let target: OutputTarget = cli.target.into();

    match cli.command {
        Some(Commands::Watch) => watch_mode(&root, target, cli.copy),
        Some(Commands::Sync) => sync_mode(&root, target, cli.copy),
        None => full_scan(&root, target, cli.copy),
    }
}

fn full_scan(root: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    let service = SyncService::new(root);
    let memory = service.full_scan()?;

    memory.save(root)?;
    let output = write_output(root, &memory, target)?;

    let tokens = estimate_tokens(&output);
    println!(
        "✓ Generated context ({} files, {})",
        memory.files.len(),
        format_token_count(tokens)
    );

    if copy {
        copy_to_clipboard(&output)?;
    }

    Ok(())
}

fn sync_mode(root: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    let service = SyncService::new(root);
    let existing = Memory::load(root).unwrap_or_default();

    let memory = service.incremental_sync(existing)?;

    memory.save(root)?;
    let output = write_output(root, &memory, target)?;

    let tokens = estimate_tokens(&output);
    println!(
        "✓ Synced context ({} files, {})",
        memory.files.len(),
        format_token_count(tokens)
    );

    if copy {
        copy_to_clipboard(&output)?;
    }

    Ok(())
}

fn watch_mode(root: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    println!("👁 Watching for changes... (Ctrl+C to stop)");

    let service = SyncService::new(root);
    let mut memory = service.full_scan()?;
    memory.save(root)?;
    let output = write_output(root, &memory, target)?;

    let tokens = estimate_tokens(&output);
    println!(
        "✓ Initial context ({} files, {})",
        memory.files.len(),
        format_token_count(tokens)
    );

    if copy {
        copy_to_clipboard(&output)?;
    }

    let (tx, rx) = channel();
    let mut debouncer = new_debouncer(Duration::from_millis(200), tx)?;
    debouncer.watcher().watch(root, RecursiveMode::Recursive)?;

    let formatter = get_formatter(target);
    let output_name = format!("context.{}", formatter.extension());

    loop {
        match rx.recv() {
            Ok(Ok(events)) => {
                let relevant = events.iter().any(|e| {
                    e.kind == DebouncedEventKind::Any
                        && !e.path.ends_with(&output_name)
                        && !e.path.ends_with(".mu_memory.json")
                        && !is_ignored_path(&e.path)
                });

                if relevant {
                    match service.incremental_sync(memory.clone()) {
                        Ok(new_memory) => {
                            memory = new_memory;
                            let _ = memory.save(root);
                            if let Ok(out) = write_output(root, &memory, target) {
                                let tokens = estimate_tokens(&out);
                                println!(
                                    "✓ Synced ({} files, {})",
                                    memory.files.len(),
                                    format_token_count(tokens)
                                );
                                if copy {
                                    let _ = copy_to_clipboard(&out);
                                }
                            }
                        }
                        Err(e) => eprintln!("✗ Error: {}", e),
                    }
                }
            }
            Ok(Err(e)) => eprintln!("Watch error: {:?}", e),
            Err(e) => {
                eprintln!("Channel error: {}", e);
                break;
            }
        }
    }

    Ok(())
}

fn write_output(root: &Path, memory: &Memory, target: OutputTarget) -> Result<String> {
    let formatter = get_formatter(target);
    let output = formatter.format(memory);
    let filename = format!("context.{}", formatter.extension());
    let path = root.join(&filename);

    let file = File::create(&path)?;
    let mut writer = BufWriter::new(file);
    write!(writer, "{}", output)?;
    writer.flush()?;

    Ok(output)
}

fn copy_to_clipboard(content: &str) -> Result<()> {
    match Clipboard::new() {
        Ok(mut clipboard) => {
            clipboard
                .set_text(content.to_string())
                .context("Failed to copy to clipboard")?;
            println!("📋 Copied to clipboard");
            Ok(())
        }
        Err(e) => {
            eprintln!("⚠ Clipboard unavailable: {}", e);
            Ok(())
        }
    }
}
