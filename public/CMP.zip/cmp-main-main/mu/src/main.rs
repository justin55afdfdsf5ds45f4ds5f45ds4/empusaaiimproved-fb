use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use notify_debouncer_mini::{new_debouncer, notify::RecursiveMode, DebouncedEventKind};
use std::collections::HashSet;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};
use std::sync::mpsc::channel;
use std::time::Duration;
use walkdir::WalkDir;

const OUTPUT_FILE: &str = "context.xml";
// CRITICAL: These directories are ALWAYS skipped at the iterator level.
// filter_entry() prevents descending into them entirely, saving I/O and RAM.
// This list overrides any user config—these folders should never be mapped.
const IGNORED_DIRS: &[&str] = &[
    "node_modules",
    ".git",
    "target",
    "dist",
    "vendor",
    ".next",
    // Additional common ignores
    "build",
    ".env",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "coverage",
    ".nuxt",
];
const IGNORED_FILES: &[&str] = &[".DS_Store", ".env", ".env.local", "context.xml"];

#[derive(Parser)]
#[command(name = "mu")]
#[command(about = "Memory Unit - Deterministic codebase mapper for AI context injection")]
#[command(version)]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand)]
enum Commands {
    /// Watch for file changes and auto-regenerate context.xml
    Watch,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let root = std::env::current_dir().context("Failed to get current directory")?;

    match cli.command {
        Some(Commands::Watch) => watch_mode(&root),
        None => {
            generate_map(&root)?;
            println!("✓ Generated {}", OUTPUT_FILE);
            Ok(())
        }
    }
}

fn generate_map(root: &Path) -> Result<()> {
    let output_path = root.join(OUTPUT_FILE);
    let file = File::create(&output_path).context("Failed to create output file")?;
    let mut writer = BufWriter::new(file);

    writeln!(writer, "<project_map>")?;

    let ignored_dirs: HashSet<&str> = IGNORED_DIRS.iter().copied().collect();
    let ignored_files: HashSet<&str> = IGNORED_FILES.iter().copied().collect();

    let mut entries: Vec<PathBuf> = WalkDir::new(root)
        .into_iter()
        .filter_entry(|e| !should_skip_dir(e, &ignored_dirs))
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .filter(|e| {
            e.file_name()
                .to_str()
                .map(|n| !ignored_files.contains(n))
                .unwrap_or(false)
        })
        .map(|e| e.into_path())
        .collect();

    // Sort for deterministic output
    entries.sort();

    for path in entries {
        if let Some(content) = read_text_file(&path) {
            let rel_path = path
                .strip_prefix(root)
                .unwrap_or(&path)
                .to_string_lossy()
                .replace('\\', "/");

            writeln!(writer, "<file path=\"{}\">", escape_xml_attr(&rel_path))?;
            write!(writer, "{}", escape_xml_content(&content))?;
            if !content.ends_with('\n') {
                writeln!(writer)?;
            }
            writeln!(writer, "</file>")?;
        }
    }

    writeln!(writer, "</project_map>")?;
    writer.flush()?;
    Ok(())
}

fn should_skip_dir(entry: &walkdir::DirEntry, ignored: &HashSet<&str>) -> bool {
    entry
        .file_name()
        .to_str()
        .map(|s| ignored.contains(s))
        .unwrap_or(false)
}

fn read_text_file(path: &Path) -> Option<String> {
    let content = fs::read(path).ok()?;

    // Skip binary files: check for null bytes in first 8KB
    let check_len = content.len().min(8192);
    if content[..check_len].contains(&0) {
        return None;
    }

    // Attempt UTF-8 decode
    String::from_utf8(content).ok()
}

fn escape_xml_attr(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('"', "&quot;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

fn escape_xml_content(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

fn watch_mode(root: &Path) -> Result<()> {
    println!("👁 Watching for changes... (Ctrl+C to stop)");
    generate_map(root)?;
    println!("✓ Initial {} generated", OUTPUT_FILE);

    let (tx, rx) = channel();
    let mut debouncer = new_debouncer(Duration::from_millis(200), tx)?;

    debouncer
        .watcher()
        .watch(root, RecursiveMode::Recursive)?;

    let output_path = root.join(OUTPUT_FILE);

    loop {
        match rx.recv() {
            Ok(Ok(events)) => {
                let relevant = events.iter().any(|e| {
                    e.kind == DebouncedEventKind::Any
                        && e.path != output_path
                        && !is_ignored_path(&e.path)
                });

                if relevant {
                    match generate_map(root) {
                        Ok(_) => println!("✓ Regenerated {}", OUTPUT_FILE),
                        Err(e) => eprintln!("✗ Error: {}", e),
                    }
                }
            }
            Ok(Err(e)) => eprintln!("Watch error: {:?}", e),
            Err(e) => {
                eprintln!("Channel error: {}", e);
                break;
            }
        }
    }

    Ok(())
}

fn is_ignored_path(path: &Path) -> bool {
    path.components().any(|c| {
        c.as_os_str()
            .to_str()
            .map(|s| IGNORED_DIRS.contains(&s) || IGNORED_FILES.contains(&s))
            .unwrap_or(false)
    })
}
