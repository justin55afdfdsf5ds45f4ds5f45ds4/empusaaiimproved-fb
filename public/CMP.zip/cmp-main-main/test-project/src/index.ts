import { greet } from './utils/greeting';
import { formatDate } from './utils/date';
import { User } from './models/user';

const user: User = { name: 'World', createdAt: new Date() };

// THE BUG: This function 'calculateTotal' does not exist!
console.log(calculateTotal(user));