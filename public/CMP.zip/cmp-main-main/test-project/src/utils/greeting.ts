import { capitalize } from './string';

export const greet = (name: string): string => {
    return `Hello, ${capitalize(name)}!`;
};
