use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::SystemTime;

const MEMORY_FILE: &str = ".cmp_memory.json";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileEntry {
    pub path: String,
    pub content: String,
    pub modified: u64,
    pub hash: u64,
}

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct Memory {
    pub version: u32,
    pub files: HashMap<String, FileEntry>,
    pub last_sync: u64,
}

impl Memory {
    pub fn load(root: &Path) -> Result<Self> {
        let path = root.join(MEMORY_FILE);
        if path.exists() {
            let data = fs::read_to_string(&path)?;
            Ok(serde_json::from_str(&data)?)
        } else {
            Ok(Self::default())
        }
    }

    pub fn save(&self, root: &Path) -> Result<()> {
        let path = root.join(MEMORY_FILE);
        let data = serde_json::to_string_pretty(self)?;
        fs::write(path, data)?;
        Ok(())
    }

    pub fn get_dirty_files(&self, current_files: &[(PathBuf, u64)]) -> Vec<PathBuf> {
        let mut dirty = Vec::new();
        
        for (path, modified) in current_files {
            let rel_path = path.to_string_lossy().replace('\\', "/");
            match self.files.get(&rel_path) {
                Some(entry) if entry.modified >= *modified => continue,
                _ => dirty.push(path.clone()),
            }
        }
        dirty
    }

    pub fn patch(&mut self, updates: Vec<FileEntry>) {
        for entry in updates {
            self.files.insert(entry.path.clone(), entry);
        }
        self.last_sync = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
    }

    pub fn remove_deleted(&mut self, existing_paths: &[String]) {
        let existing: std::collections::HashSet<_> = existing_paths.iter().collect();
        self.files.retain(|k, _| existing.contains(k));
    }
}

pub fn hash_content(content: &str) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    content.hash(&mut hasher);
    hasher.finish()
}
