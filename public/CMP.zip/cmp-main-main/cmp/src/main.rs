mod formatter;
mod mapper;
mod memory;
mod scanner;
mod sync;

use anyhow::{Context, Result};
use arboard::Clipboard;
use clap::{Parser, Subcommand, ValueEnum};
use formatter::{estimate_tokens, format_token_count, get_formatter, OutputTarget};
use mapper::{extract_skeleton, MappedFile};
use memory::Memory;
use notify_debouncer_mini::{new_debouncer, notify::RecursiveMode, DebouncedEventKind};
use scanner::{is_ignored_path, scan_files_with_noise_tracking, IgnoredFile};
use std::collections::HashSet;
use std::fs::{self, File};
use std::io::{self, BufWriter, Write};
use std::path::{Path, PathBuf};
use std::sync::mpsc::channel;
use std::time::Duration;
use sync::SyncService;

const TOKEN_THRESHOLD_GREEN: usize = 10_000;
const TOKEN_THRESHOLD_YELLOW: usize = 30_000;
const WATCH_DEBOUNCE_MS: u64 = 500;

#[derive(Parser)]
#[command(name = "cmp")]
#[command(about = "Memory Unit - Deterministic codebase mapper for AI context injection")]
#[command(version)]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,
    
    /// Target folder to scan (defaults to current directory)
    #[arg(value_name = "PATH")]
    path: Option<PathBuf>,
    
    #[arg(short, long, default_value = "claude")]
    target: Target,
    
    #[arg(short, long)]
    copy: bool,
    
    #[arg(long = "ignore", value_name = "FILE")]
    ignore_files: Vec<String>,
}

#[derive(Clone, ValueEnum, Default)]
enum Target { Raw, #[default] Claude, Cursor }

impl From<Target> for OutputTarget {
    fn from(t: Target) -> Self {
        match t { Target::Raw => OutputTarget::Raw, Target::Claude => OutputTarget::Claude, Target::Cursor => OutputTarget::Cursor }
    }
}

#[derive(Subcommand)]
enum Commands {
    /// Mode A: Skeleton map (imports + signatures only)
    Map {
        #[arg(value_name = "PATH")]
        path: Option<PathBuf>,
    },
    /// Mode B: Full source code (saves to disk)
    Source {
        #[arg(value_name = "PATH")]
        path: Option<PathBuf>,
    },
    /// Live watcher - keeps skeleton map updated, NO full source to disk
    Watch {
        #[arg(value_name = "PATH")]
        path: Option<PathBuf>,
    },
    /// Copy full source to clipboard (ephemeral - no disk write)
    Copy {
        #[arg(value_name = "PATH")]
        path: Option<PathBuf>,
    },
    /// Incremental sync
    Sync {
        #[arg(value_name = "PATH")]
        path: Option<PathBuf>,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let cwd = std::env::current_dir().context("Failed to get current directory")?;
    let target: OutputTarget = cli.target.into();
    let ignore_set: HashSet<String> = cli.ignore_files.into_iter().collect();

    match cli.command {
        Some(Commands::Map { path }) => {
            let root = resolve_path(&cwd, path.or(cli.path.clone()))?;
            map_mode(&root, &cwd, target, cli.copy)
        }
        Some(Commands::Source { path }) => {
            let root = resolve_path(&cwd, path.or(cli.path.clone()))?;
            source_mode(&root, &cwd, target, cli.copy, &ignore_set)
        }
        Some(Commands::Watch { path }) => {
            let root = resolve_path(&cwd, path.or(cli.path.clone()))?;
            live_watch_mode(&root, &cwd, target)
        }
        Some(Commands::Copy { path }) => {
            let root = resolve_path(&cwd, path.or(cli.path.clone()))?;
            copy_mode(&root, target, &ignore_set)
        }
        Some(Commands::Sync { path }) => {
            let root = resolve_path(&cwd, path.or(cli.path.clone()))?;
            sync_mode(&root, &cwd, target, cli.copy)
        }
        None => {
            let root = resolve_path(&cwd, cli.path)?;
            source_mode(&root, &cwd, target, cli.copy, &ignore_set)
        }
    }
}

fn resolve_path(cwd: &Path, path: Option<PathBuf>) -> Result<PathBuf> {
    match path {
        Some(p) => {
            let resolved = if p.is_absolute() { p } else { cwd.join(&p) };
            if !resolved.exists() { anyhow::bail!("Path does not exist: {}", resolved.display()); }
            if !resolved.is_dir() { anyhow::bail!("Path is not a directory: {}", resolved.display()); }
            Ok(resolved)
        }
        None => Ok(cwd.to_path_buf()),
    }
}

// =============================================================================
// LIVE WATCH MODE - Lightweight skeleton map only, NO full source to disk
// =============================================================================

fn live_watch_mode(root: &Path, output_dir: &Path, target: OutputTarget) -> Result<()> {
    println!("LIVE WATCHER: Monitoring {}...", root.display());
    println!("============================================");
    println!("  Mode: Skeleton Map ONLY (lightweight)");
    println!("  Debounce: {}ms", WATCH_DEBOUNCE_MS);
    println!("  Full source: Use 'cmp copy' when needed");
    println!("============================================");
    println!("Press Ctrl+C to stop\n");

    // Initial skeleton map generation
    let (mapped_files, ignored) = generate_skeleton_map(root)?;
    let output = format_map_output(&mapped_files, target);
    let tokens = estimate_tokens(&output);
    
    // Write lightweight map file
    let formatter = get_formatter(target);
    let map_filename = format!("cmp_map.{}", formatter.extension());
    let map_path = output_dir.join(&map_filename);
    fs::write(&map_path, &output)?;
    
    print_cmp_report(mapped_files.len(), &ignored);
    println!("Map: {} | {}", map_filename, format_token_count(tokens));
    println!("Watching for changes...\n");

    // Setup file watcher with 500ms debounce
    let (tx, rx) = channel();
    let mut debouncer = new_debouncer(Duration::from_millis(WATCH_DEBOUNCE_MS), tx)?;
    debouncer.watcher().watch(root, RecursiveMode::Recursive)?;

    loop {
        match rx.recv() {
            Ok(Ok(events)) => {
                // Filter out irrelevant events (our own output, ignored paths)
                let relevant = events.iter().any(|e| {
                    e.kind == DebouncedEventKind::Any
                        && !e.path.ends_with(&map_filename)
                        && !e.path.ends_with(".cmp_memory.json")
                        && !e.path.ends_with("context.xml")
                        && !e.path.ends_with("context.md")
                        && !e.path.ends_with("context.json")
                        && !is_ignored_path(&e.path)
                });

                if relevant {
                    // Regenerate skeleton map only
                    match generate_skeleton_map(root) {
                        Ok((files, _)) => {
                            let output = format_map_output(&files, target);
                            let tokens = estimate_tokens(&output);
                            if fs::write(&map_path, &output).is_ok() {
                                println!("[{}] Map updated: {} files, {}", 
                                    chrono_time(), files.len(), format_token_count(tokens));
                            }
                        }
                        Err(e) => eprintln!("Error updating map: {}", e),
                    }
                }
            }
            Ok(Err(e)) => eprintln!("Watch error: {:?}", e),
            Err(e) => { eprintln!("Channel error: {}", e); break; }
        }
    }
    Ok(())
}

fn generate_skeleton_map(root: &Path) -> Result<(Vec<MappedFile>, Vec<IgnoredFile>)> {
    let scan_result = scan_files_with_noise_tracking(root)?;
    let mut mapped_files: Vec<MappedFile> = Vec::new();
    
    for path in &scan_result.files {
        if let Some(content) = read_text_file(path) {
            let rel_path = path.strip_prefix(root).unwrap_or(path);
            let skeleton = extract_skeleton(rel_path, &content);
            if !skeleton.imports.is_empty() || !skeleton.signatures.is_empty() {
                mapped_files.push(skeleton);
            }
        }
    }
    
    Ok((mapped_files, scan_result.ignored_noise))
}

fn chrono_time() -> String {
    use std::time::SystemTime;
    let now = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap_or_default();
    let secs = now.as_secs() % 86400;
    let hours = (secs / 3600) % 24;
    let mins = (secs % 3600) / 60;
    let secs = secs % 60;
    format!("{:02}:{:02}:{:02}", hours, mins, secs)
}

// =============================================================================
// COPY MODE - Ephemeral full source to clipboard (NO disk write)
// =============================================================================

fn copy_mode(root: &Path, target: OutputTarget, ignore_set: &HashSet<String>) -> Result<()> {
    println!("COPY MODE: Generating full source (ephemeral)...");
    
    let service = SyncService::new(root);
    let result = service.full_scan_with_noise()?;
    let mut memory = result.memory;
    let ignored = result.ignored_noise;

    // Apply user ignores
    if !ignore_set.is_empty() {
        memory.files.retain(|path, _| {
            let filename = path.rsplit('/').next().unwrap_or(path);
            !ignore_set.contains(filename) && !ignore_set.contains(path)
        });
    }

    print_cmp_report(memory.files.len(), &ignored);

    // Generate output to memory only (NOT to disk)
    let formatter = get_formatter(target);
    let output = formatter.format(&memory);
    let tokens = estimate_tokens(&output);

    println!("Generated: {} files, {}", memory.files.len(), format_token_count(tokens));

    // Token budget check then copy to clipboard
    if tokens > TOKEN_THRESHOLD_YELLOW {
        println!("\nHIGH COST WARNING");
        println!("Token count: {} | Estimated cost: ~${:.2}", format_token_count(tokens), estimate_cost(tokens));
        println!("Recommend using `cmp map` first or targeting a specific folder.\n");
        print!("[?] Copy to clipboard anyway? (y/N) ");
        io::stdout().flush()?;
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        if input.trim().eq_ignore_ascii_case("y") || input.trim().eq_ignore_ascii_case("yes") {
            copy_to_clipboard(&output)?;
        } else {
            println!("Cancelled. No data written to disk or clipboard.");
        }
    } else if tokens > TOKEN_THRESHOLD_GREEN {
        println!("\nMODERATE COST");
        println!("Token count: {} | Estimated cost: ~${:.2}", format_token_count(tokens), estimate_cost(tokens));
        print!("[?] Copy to clipboard? (Y/n) ");
        io::stdout().flush()?;
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        let input = input.trim();
        if input.is_empty() || input.eq_ignore_ascii_case("y") || input.eq_ignore_ascii_case("yes") {
            copy_to_clipboard(&output)?;
        } else {
            println!("Cancelled. No data written to disk or clipboard.");
        }
    } else {
        // Green zone - copy directly
        copy_to_clipboard(&output)?;
    }

    Ok(())
}

// =============================================================================
// MAP MODE - One-shot skeleton map generation
// =============================================================================

fn map_mode(root: &Path, output_dir: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    println!("MAP MODE: Scanning {}...", root.display());
    
    let (mapped_files, ignored) = generate_skeleton_map(root)?;
    print_cmp_report(mapped_files.len(), &ignored);

    let output = format_map_output(&mapped_files, target);
    let tokens = estimate_tokens(&output);

    let formatter = get_formatter(target);
    let filename = format!("cmp_map.{}", formatter.extension());
    fs::write(output_dir.join(&filename), &output)?;

    println!("Generated: {} | {} files, {}", filename, mapped_files.len(), format_token_count(tokens));
    handle_token_budget_copy(&output, tokens, copy)?;
    Ok(())
}

// =============================================================================
// SOURCE MODE - Full source to disk (legacy behavior)
// =============================================================================

fn source_mode(root: &Path, output_dir: &Path, target: OutputTarget, copy: bool, ignore_set: &HashSet<String>) -> Result<()> {
    println!("SOURCE MODE: Scanning {}...", root.display());
    
    let service = SyncService::new(root);
    let result = service.full_scan_with_noise()?;
    let mut memory = result.memory;
    let ignored = result.ignored_noise;

    if !ignore_set.is_empty() {
        memory.files.retain(|path, _| {
            let filename = path.rsplit('/').next().unwrap_or(path);
            !ignore_set.contains(filename) && !ignore_set.contains(path)
        });
        println!("User-ignored {} file(s)", ignore_set.len());
    }

    print_cmp_report(memory.files.len(), &ignored);
    let memory = handle_ignored_consent(&service, memory, &ignored)?;
    memory.save(output_dir)?;
    let output = write_output(output_dir, &memory, target)?;
    let tokens = estimate_tokens(&output);
    println!("Generated context ({} files, {})", memory.files.len(), format_token_count(tokens));
    handle_token_budget_copy(&output, tokens, copy)?;
    Ok(())
}

// =============================================================================
// SYNC MODE - Incremental update
// =============================================================================

fn sync_mode(root: &Path, output_dir: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    println!("SYNC MODE: Scanning {}...", root.display());
    
    let service = SyncService::new(root);
    let existing = Memory::load(output_dir).unwrap_or_default();
    let result = service.incremental_sync_with_noise(existing)?;
    let memory = result.memory;
    let ignored = result.ignored_noise;

    print_cmp_report(memory.files.len(), &ignored);
    let memory = handle_ignored_consent(&service, memory, &ignored)?;
    memory.save(output_dir)?;
    let output = write_output(output_dir, &memory, target)?;
    let tokens = estimate_tokens(&output);
    println!("Synced context ({} files, {})", memory.files.len(), format_token_count(tokens));
    handle_token_budget_copy(&output, tokens, copy)?;
    Ok(())
}

// =============================================================================
// Formatting helpers
// =============================================================================

fn format_map_output(files: &[MappedFile], target: OutputTarget) -> String {
    match target {
        OutputTarget::Claude => format_map_xml(files),
        OutputTarget::Cursor => format_map_markdown(files),
        OutputTarget::Raw => format_map_json(files),
    }
}

fn format_map_xml(files: &[MappedFile]) -> String {
    let mut out = String::from("<context type=\"skeleton_map\">\n<project_map>\n");
    for file in files {
        out.push_str(&format!("<file path=\"{}\">\n", escape_xml(&file.path)));
        out.push_str(&escape_xml(&file.format()));
        out.push_str("</file>\n");
    }
    out.push_str("</project_map>\n</context>");
    out
}

fn format_map_markdown(files: &[MappedFile]) -> String {
    let mut out = String::from("# Project Skeleton Map\n\n");
    for file in files {
        let ext = file.path.rsplit('.').next().unwrap_or("txt");
        out.push_str(&format!("## {}\n\n`{}\n{}\n`\n\n", file.path, ext, file.format()));
    }
    out
}

fn format_map_json(files: &[MappedFile]) -> String {
    let json_files: Vec<_> = files.iter().map(|f| serde_json::json!({"path": f.path, "imports": f.imports, "signatures": f.signatures})).collect();
    serde_json::to_string_pretty(&json_files).unwrap_or_default()
}

// =============================================================================
// CMP Report
// =============================================================================

fn print_cmp_report(included_count: usize, ignored: &[IgnoredFile]) {
    println!();
    println!("CMP REPORT:");
    println!("============================================");
    println!("  Included: {} files (Source Code)", included_count);
    if ignored.is_empty() {
        println!("  Ignored Noise: None");
    } else {
        let noise_names: Vec<&str> = ignored.iter().take(5).map(|i| i.path.rsplit('/').next().unwrap_or(&i.path)).collect();
        let display = if ignored.len() > 5 { format!("{}, ... (+{} more)", noise_names.join(", "), ignored.len() - 5) } else { noise_names.join(", ") };
        let total_tokens: usize = ignored.iter().map(|i| i.estimated_tokens).sum();
        println!("  Ignored Noise: {} (saved ~{})", display, format_token_count(total_tokens));
    }
    println!("============================================");
}

// =============================================================================
// Token Budget Check
// =============================================================================

fn handle_token_budget_copy(content: &str, tokens: usize, auto_copy: bool) -> Result<()> {
    if tokens > TOKEN_THRESHOLD_YELLOW {
        println!("\nHIGH COST WARNING");
        println!("Token count: {} | Estimated cost: ~${:.2}", format_token_count(tokens), estimate_cost(tokens));
        println!("Recommend using `cmp map` first or targeting a specific folder.\n");
        print!("[?] Proceed with copy? (y/N) ");
        io::stdout().flush()?;
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        if input.trim().eq_ignore_ascii_case("y") || input.trim().eq_ignore_ascii_case("yes") { copy_to_clipboard(content)?; }
        else { println!("Not copied (file still saved to disk)"); }
    } else if tokens > TOKEN_THRESHOLD_GREEN {
        println!("\nMODERATE COST");
        println!("Token count: {} | Estimated cost: ~${:.2}", format_token_count(tokens), estimate_cost(tokens));
        print!("[?] Proceed with copy? (Y/n) ");
        io::stdout().flush()?;
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        let input = input.trim();
        if input.is_empty() || input.eq_ignore_ascii_case("y") || input.eq_ignore_ascii_case("yes") { copy_to_clipboard(content)?; }
        else { println!("Not copied (file still saved to disk)"); }
    } else {
        if auto_copy { copy_to_clipboard(content)?; }
        else {
            print!("[?] Copy to clipboard? (Y/n) ");
            io::stdout().flush()?;
            let mut input = String::new();
            io::stdin().read_line(&mut input)?;
            let input = input.trim();
            if input.is_empty() || input.eq_ignore_ascii_case("y") || input.eq_ignore_ascii_case("yes") { copy_to_clipboard(content)?; }
            else { println!("Saved to disk only"); }
        }
    }
    Ok(())
}

fn estimate_cost(tokens: usize) -> f64 { (tokens as f64 / 1000.0) * 0.01 }

// =============================================================================
// Helper Functions
// =============================================================================

fn write_output(root: &Path, memory: &Memory, target: OutputTarget) -> Result<String> {
    let formatter = get_formatter(target);
    let output = formatter.format(memory);
    let filename = format!("context.{}", formatter.extension());
    let file = File::create(root.join(&filename))?;
    let mut writer = BufWriter::new(file);
    write!(writer, "{}", output)?;
    writer.flush()?;
    Ok(output)
}

fn copy_to_clipboard(content: &str) -> Result<()> {
    match Clipboard::new() {
        Ok(mut clipboard) => { clipboard.set_text(content.to_string()).context("Failed to copy to clipboard")?; println!("Copied to clipboard"); Ok(()) }
        Err(e) => { eprintln!("Clipboard unavailable: {}", e); Ok(()) }
    }
}

fn read_text_file(path: &Path) -> Option<String> {
    let content = fs::read(path).ok()?;
    let check_len = content.len().min(8192);
    if content[..check_len].contains(&0) { return None; }
    String::from_utf8(content).ok()
}

fn escape_xml(s: &str) -> String { s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;") }

fn handle_ignored_consent(service: &SyncService, mut memory: Memory, ignored: &[IgnoredFile]) -> Result<Memory> {
    if ignored.is_empty() { return Ok(memory); }
    let total_tokens: usize = ignored.iter().map(|i| i.estimated_tokens).sum();
    print!("\n[?] Force-include {} ignored files? (y/N) ", ignored.len());
    io::stdout().flush()?;
    let mut input = String::new();
    io::stdin().read_line(&mut input)?;
    if input.trim().eq_ignore_ascii_case("y") || input.trim().eq_ignore_ascii_case("yes") {
        println!("WARNING: Adding ~{} of noise!", format_token_count(total_tokens));
        service.include_ignored_files(&mut memory, ignored);
        println!("Force-included {} files", ignored.len());
    } else { println!("Keeping noise files excluded (recommended)"); }
    Ok(memory)
}
