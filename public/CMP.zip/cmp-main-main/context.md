# Project Context

## File Structure

- `README.md`
- `chat_log.txt`
- `compressor.py`
- `injector.py`
- `mu/.gitignore`
- `mu/Cargo.lock`
- `mu/Cargo.toml`
- `mu/README.md`
- `mu/src/formatter.rs`
- `mu/src/main.rs`
- `mu/src/memory.rs`
- `mu/src/scanner.rs`
- `mu/src/sync.rs`
- `requirements.txt`
- `state_key.md`
- `verify_ignore.py`

## File Contents

### README.md

```md
# CMP (Context Memory Protocol) - Beta v0.2

CMP is a local "State Injection" layer designed to solve Context Amnesia in long LLM sessions.

## The Problem

LLMs treat every session as a fresh start. "Project Prompts" are static and expensive.

CMP creates a dynamic **State Key** that captures architectural decisions, negative constraints, and active variables from your previous session.

## Components

### mu (Memory Unit) - Rust CLI

A blazing-fast codebase mapper that generates deterministic XML snapshots for AI context windows.

```bash
# Build
cd mu && cargo build --release

# Generate context.xml
./mu/target/release/mu

# Watch mode (auto-regenerates on changes)
./mu/target/release/mu watch
```

Output format:
```xml
<project_map>
  <file path="src/main.rs">[content]</file>
  <file path="README.md">[content]</file>
</project_map>
```

Features:
- Deterministic output (sorted paths)
- Auto-ignores: `.git`, `node_modules`, `target`, `dist`, `build`, `__pycache__`
- Skips binary files
- Watch mode with 200ms debounce

### Compressor (`compressor.py`)

Uses `mu` for dependency analysis and extracts structured snapshots of your current focus.

### Injector (`injector.py`)

Formats the State Key into an XML block optimized for Claude/GPT system prompts.

## Quick Start

```bash
# Option 1: Full codebase map
./mu/target/release/mu

# Option 2: Targeted dependency analysis
python compressor.py <target_file_or_node>
python injector.py
```

Paste the output into your new chat to restore context.

## Ignored Directories

The `mu` CLI automatically skips these directories at the iterator level to prevent memory crashes on large projects:

- `node_modules`
- `.git`
- `target`
- `dist`
- `vendor`
- `.next`
- `build`, `__pycache__`, `.venv`, `venv`, `.idea`, `.vscode`, `coverage`, `.nuxt`

This filter is hard-coded and overrides any user config.

## Security

- Runs 100% locally
- No LLM calls required for compression
- No data sent to external servers

## Support

- Email: justinlord@empusaai.com
- X: @justin_lords
```

### chat_log.txt

```txt
Paste your chat history here...
```

### compressor.py

```py
import json
import os
import shutil
import subprocess
import sys


def get_mu_analysis(target: str) -> dict | None:
    """
    Run `mu deps <target> --format json` and return parsed JSON output.
    Returns None if mu is not available or command fails.
    """
    # Check if mu is in PATH
    if not shutil.which("mu"):
        print("Warning: 'mu' CLI not found in PATH. Skipping dependency analysis.")
        return None

    try:
        result = subprocess.run(
            ["mu", "deps", target, "--format", "json"],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode != 0:
            print(f"Warning: mu command failed: {result.stderr.strip()}")
            return None

        return json.loads(result.stdout)

    except subprocess.TimeoutExpired:
        print("Warning: mu command timed out.")
        return None
    except json.JSONDecodeError as e:
        print(f"Warning: Failed to parse mu output as JSON: {e}")
        return None
    except Exception as e:
        print(f"Warning: Unexpected error running mu: {e}")
        return None


def deps_to_xml(deps_output: dict) -> str:
    """
    Convert mu deps JSON output to token-efficient XML format.
    """
    node_id = deps_output.get("node_id", "")
    node_name = deps_output.get("node_name", "unknown")
    dependencies = deps_output.get("dependencies", [])

    # Extract node type from node_id (e.g., "cls:path:Name" -> "class")
    node_type = "unknown"
    if node_id.startswith("cls:"):
        node_type = "class"
    elif node_id.startswith("fn:"):
        node_type = "function"
    elif node_id.startswith("mod:"):
        node_type = "module"

    # Extract file path from node_id
    parts = node_id.split(":")
    file_path = parts[1] if len(parts) > 1 else ""

    lines = ["<CURRENT_FOCUS>"]
    lines.append(f'  <NODE name="{node_name}" type="{node_type}" path="{file_path}">')

    if dependencies:
        lines.append(f'    <DEPS count="{len(dependencies)}">')
        for dep in dependencies:
            dep_name = dep.get("name", "")
            dep_type = dep.get("node_type", "")
            dep_path = dep.get("file_path", "")
            lines.append(f'      <DEP name="{dep_name}" type="{dep_type}" path="{dep_path}" />')
        lines.append("    </DEPS>")

    lines.append("  </NODE>")
    lines.append("</CURRENT_FOCUS>")

    return "\n".join(lines)


def compress_chat_log(target: str | None = None):
    """
    Generate state snapshot. If target is provided, includes mu dependency analysis.
    """
    output_parts = []

    # Run mu analysis if target provided
    if target:
        deps_output = get_mu_analysis(target)
        if deps_output:
            xml_block = deps_to_xml(deps_output)
            output_parts.append(xml_block)
        else:
            output_parts.append("<!-- mu analysis unavailable -->")

    # Write state key
    with open("state_key.md", "w", encoding="utf-8") as f:
        f.write("\n\n".join(output_parts) if output_parts else "<!-- No state captured -->")

    print("State snapshot saved to state_key.md")


if __name__ == "__main__":
    target_file = sys.argv[1] if len(sys.argv) > 1 else None
    compress_chat_log(target_file)
```

### injector.py

```py
from datetime import datetime, timezone


def inject_state():
    with open("state_key.md", "r", encoding="utf-8") as f:
        state_content = f.read()
    
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    
    print('<cmp_protocol version="0.1">')
    print("<meta>")
    print("<session_id>a1b2-c3d4</session_id>")
    print(f"<timestamp>{timestamp}</timestamp>")
    print("<compression_ratio>4.5x</compression_ratio>")
    print("</meta>")
    print("<state_key>")
    print(state_content)
    print("</state_key>")
    print("</cmp_protocol>")


if __name__ == "__main__":
    inject_state()
```

### mu/.gitignore

```gitignore
/target/
```

### mu/Cargo.lock

```lock
# This file is automatically @generated by Cargo.
# It is not intended for manual editing.
version = 4

[[package]]
name = "adler2"
version = "2.0.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "320119579fcad9c21884f5c4861d16174d0e06250625266f50fe6898340abefa"

[[package]]
name = "aho-corasick"
version = "1.1.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ddd31a130427c27518df266943a5308ed92d4b226cc639f5a8f1002816174301"
dependencies = [
 "memchr",
]

[[package]]
name = "anstream"
version = "0.6.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "43d5b281e737544384e969a5ccad3f1cdd24b48086a0fc1b2a5262a26b8f4f4a"
dependencies = [
 "anstyle",
 "anstyle-parse",
 "anstyle-query",
 "anstyle-wincon",
 "colorchoice",
 "is_terminal_polyfill",
 "utf8parse",
]

[[package]]
name = "anstyle"
version = "1.0.13"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5192cca8006f1fd4f7237516f40fa183bb07f8fbdfedaa0036de5ea9b0b45e78"

[[package]]
name = "anstyle-parse"
version = "0.2.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4e7644824f0aa2c7b9384579234ef10eb7efb6a0deb83f9630a49594dd9c15c2"
dependencies = [
 "utf8parse",
]

[[package]]
name = "anstyle-query"
version = "1.1.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "40c48f72fd53cd289104fc64099abca73db4166ad86ea0b4341abe65af83dadc"
dependencies = [
 "windows-sys 0.61.2",
]

[[package]]
name = "anstyle-wincon"
version = "3.0.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "291e6a250ff86cd4a820112fb8898808a366d8f9f58ce16d1f538353ad55747d"
dependencies = [
 "anstyle",
 "once_cell_polyfill",
 "windows-sys 0.61.2",
]

[[package]]
name = "anyhow"
version = "1.0.100"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a23eb6b1614318a8071c9b2521f36b424b2c83db5eb3a0fead4a6c0809af6e61"

[[package]]
name = "arboard"
version = "3.6.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0348a1c054491f4bfe6ab86a7b6ab1e44e45d899005de92f58b3df180b36ddaf"
dependencies = [
 "clipboard-win",
 "image",
 "log",
 "objc2",
 "objc2-app-kit",
 "objc2-core-foundation",
 "objc2-core-graphics",
 "objc2-foundation",
 "parking_lot",
 "percent-encoding",
 "windows-sys 0.60.2",
 "x11rb",
]

[[package]]
name = "autocfg"
version = "1.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c08606f8c3cbf4ce6ec8e28fb0014a2c086708fe954eaa885384a6165172e7e8"

[[package]]
name = "base64"
version = "0.21.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9d297deb1925b89f2ccc13d7635fa0714f12c87adce1c75356b39ca9b7178567"

[[package]]
name = "bit-set"
version = "0.5.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0700ddab506f33b20a03b13996eccd309a48e5ff77d0d95926aa0210fb4e95f1"
dependencies = [
 "bit-vec",
]

[[package]]
name = "bit-vec"
version = "0.6.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "349f9b6a179ed607305526ca489b34ad0a41aed5f7980fa90eb03160b69598fb"

[[package]]
name = "bitflags"
version = "1.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "bef38d45163c2f1dde094a7dfd33ccf595c92905c8f8f4fdc18d06fb1037718a"

[[package]]
name = "bitflags"
version = "2.10.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "812e12b5285cc515a9c72a5c1d3b6d46a19dac5acfef5265968c166106e31dd3"

[[package]]
name = "bstr"
version = "1.12.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "63044e1ae8e69f3b5a92c736ca6269b8d12fa7efe39bf34ddb06d102cf0e2cab"
dependencies = [
 "memchr",
 "regex-automata",
 "serde",
]

[[package]]
name = "bytemuck"
version = "1.24.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1fbdf580320f38b612e485521afda1ee26d10cc9884efaaa750d383e13e3c5f4"

[[package]]
name = "byteorder-lite"
version = "0.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8f1fe948ff07f4bd06c30984e69f5b4899c516a3ef74f34df92a2df2ab535495"

[[package]]
name = "cfg-if"
version = "1.0.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9330f8b2ff13f34540b44e946ef35111825727b38d33286ef986142615121801"

[[package]]
name = "clap"
version = "4.5.53"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c9e340e012a1bf4935f5282ed1436d1489548e8f72308207ea5df0e23d2d03f8"
dependencies = [
 "clap_builder",
 "clap_derive",
]

[[package]]
name = "clap_builder"
version = "4.5.53"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d76b5d13eaa18c901fd2f7fca939fefe3a0727a953561fefdf3b2922b8569d00"
dependencies = [
 "anstream",
 "anstyle",
 "clap_lex",
 "strsim",
]

[[package]]
name = "clap_derive"
version = "4.5.49"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2a0b5487afeab2deb2ff4e03a807ad1a03ac532ff5a2cee5d86884440c7f7671"
dependencies = [
 "heck",
 "proc-macro2",
 "quote",
 "syn",
]

[[package]]
name = "clap_lex"
version = "0.7.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a1d728cc89cf3aee9ff92b05e62b19ee65a02b5702cff7d5a377e32c6ae29d8d"

[[package]]
name = "clipboard-win"
version = "5.4.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "bde03770d3df201d4fb868f2c9c59e66a3e4e2bd06692a0fe701e7103c7e84d4"
dependencies = [
 "error-code",
]

[[package]]
name = "colorchoice"
version = "1.0.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b05b61dc5112cbb17e4b6cd61790d9845d13888356391624cbe7e41efeac1e75"

[[package]]
name = "crc32fast"
version = "1.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9481c1c90cbf2ac953f07c8d4a58aa3945c425b7185c9154d67a65e4230da511"
dependencies = [
 "cfg-if",
]

[[package]]
name = "crossbeam-channel"
version = "0.5.15"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "82b8f8f868b36967f9606790d1903570de9ceaf870a7bf9fbbd3016d636a2cb2"
dependencies = [
 "crossbeam-utils",
]

[[package]]
name = "crossbeam-utils"
version = "0.8.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d0a5c400df2834b80a4c3327b3aad3a4c4cd4de0629063962b03235697506a28"

[[package]]
name = "crunchy"
version = "0.2.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "460fbee9c2c2f33933d720630a6a0bac33ba7053db5344fac858d4b8952d77d5"

[[package]]
name = "dispatch2"
version = "0.3.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "89a09f22a6c6069a18470eb92d2298acf25463f14256d24778e1230d789a2aec"
dependencies = [
 "bitflags 2.10.0",
 "objc2",
]

[[package]]
name = "errno"
version = "0.3.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "39cab71617ae0d63f51a36d69f866391735b51691dbda63cf6f96d042b63efeb"
dependencies = [
 "libc",
 "windows-sys 0.61.2",
]

[[package]]
name = "error-code"
version = "3.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "dea2df4cf52843e0452895c455a1a2cfbb842a1e7329671acf418fdc53ed4c59"

[[package]]
name = "fancy-regex"
version = "0.12.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7493d4c459da9f84325ad297371a6b2b8a162800873a22e3b6b6512e61d18c05"
dependencies = [
 "bit-set",
 "regex",
]

[[package]]
name = "fax"
version = "0.2.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f05de7d48f37cd6730705cbca900770cab77a89f413d23e100ad7fad7795a0ab"
dependencies = [
 "fax_derive",
]

[[package]]
name = "fax_derive"
version = "0.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a0aca10fb742cb43f9e7bb8467c91aa9bcb8e3ffbc6a6f7389bb93ffc920577d"
dependencies = [
 "proc-macro2",
 "quote",
 "syn",
]

[[package]]
name = "fdeflate"
version = "0.3.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1e6853b52649d4ac5c0bd02320cddc5ba956bdb407c4b75a2c6b75bf51500f8c"
dependencies = [
 "simd-adler32",
]

[[package]]
name = "filetime"
version = "0.2.26"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "bc0505cd1b6fa6580283f6bdf70a73fcf4aba1184038c90902b92b3dd0df63ed"
dependencies = [
 "cfg-if",
 "libc",
 "libredox",
 "windows-sys 0.60.2",
]

[[package]]
name = "flate2"
version = "1.1.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "bfe33edd8e85a12a67454e37f8c75e730830d83e313556ab9ebf9ee7fbeb3bfb"
dependencies = [
 "crc32fast",
 "miniz_oxide",
]

[[package]]
name = "fsevent-sys"
version = "4.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "76ee7a02da4d231650c7cea31349b889be2f45ddb3ef3032d2ec8185f6313fd2"
dependencies = [
 "libc",
]

[[package]]
name = "gethostname"
version = "1.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1bd49230192a3797a9a4d6abe9b3eed6f7fa4c8a8a4947977c6f80025f92cbd8"
dependencies = [
 "rustix",
 "windows-link",
]

[[package]]
name = "half"
version = "2.7.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6ea2d84b969582b4b1864a92dc5d27cd2b77b622a8d79306834f1be5ba20d84b"
dependencies = [
 "cfg-if",
 "crunchy",
 "zerocopy",
]

[[package]]
name = "heck"
version = "0.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2304e00983f87ffb38b55b444b5e3b60a884b5d30c0fca7d82fe33449bbe55ea"

[[package]]
name = "image"
version = "0.25.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e6506c6c10786659413faa717ceebcb8f70731c0a60cbae39795fdf114519c1a"
dependencies = [
 "bytemuck",
 "byteorder-lite",
 "moxcms",
 "num-traits",
 "png",
 "tiff",
]

[[package]]
name = "inotify"
version = "0.9.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f8069d3ec154eb856955c1c0fbffefbf5f3c40a104ec912d4797314c1801abff"
dependencies = [
 "bitflags 1.3.2",
 "inotify-sys",
 "libc",
]

[[package]]
name = "inotify-sys"
version = "0.1.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e05c02b5e89bff3b946cedeca278abc628fe811e604f027c45a8aa3cf793d0eb"
dependencies = [
 "libc",
]

[[package]]
name = "is_terminal_polyfill"
version = "1.70.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a6cb138bb79a146c1bd460005623e142ef0181e3d0219cb493e02f7d08a35695"

[[package]]
name = "itoa"
version = "1.0.15"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4a5f13b858c8d314ee3e8f639011f7ccefe71f97f96e50151fb991f267928e2c"

[[package]]
name = "kqueue"
version = "1.1.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "eac30106d7dce88daf4a3fcb4879ea939476d5074a9b7ddd0fb97fa4bed5596a"
dependencies = [
 "kqueue-sys",
 "libc",
]

[[package]]
name = "kqueue-sys"
version = "1.0.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ed9625ffda8729b85e45cf04090035ac368927b8cebc34898e7c120f52e4838b"
dependencies = [
 "bitflags 1.3.2",
 "libc",
]

[[package]]
name = "lazy_static"
version = "1.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "bbd2bcb4c963f2ddae06a2efc7e9f3591312473c50c6685e1f298068316e66fe"

[[package]]
name = "libc"
version = "0.2.178"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "37c93d8daa9d8a012fd8ab92f088405fb202ea0b6ab73ee2482ae66af4f42091"

[[package]]
name = "libredox"
version = "0.1.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "df15f6eac291ed1cf25865b1ee60399f57e7c227e7f51bdbd4c5270396a9ed50"
dependencies = [
 "bitflags 2.10.0",
 "libc",
 "redox_syscall 0.6.0",
]

[[package]]
name = "linux-raw-sys"
version = "0.11.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "df1d3c3b53da64cf5760482273a98e575c651a67eec7f77df96b5b642de8f039"

[[package]]
name = "lock_api"
version = "0.4.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "224399e74b87b5f3557511d98dff8b14089b3dadafcab6bb93eab67d3aace965"
dependencies = [
 "scopeguard",
]

[[package]]
name = "log"
version = "0.4.29"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5e5032e24019045c762d3c0f28f5b6b8bbf38563a65908389bf7978758920897"

[[package]]
name = "memchr"
version = "2.7.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f52b00d39961fc5b2736ea853c9cc86238e165017a493d1d5c8eac6bdc4cc273"

[[package]]
name = "miniz_oxide"
version = "0.8.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1fa76a2c86f704bdb222d66965fb3d63269ce38518b83cb0575fca855ebb6316"
dependencies = [
 "adler2",
 "simd-adler32",
]

[[package]]
name = "mio"
version = "0.8.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a4a650543ca06a924e8b371db273b2756685faae30f8487da1b56505a8f78b0c"
dependencies = [
 "libc",
 "log",
 "wasi",
 "windows-sys 0.48.0",
]

[[package]]
name = "moxcms"
version = "0.7.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ac9557c559cd6fc9867e122e20d2cbefc9ca29d80d027a8e39310920ed2f0a97"
dependencies = [
 "num-traits",
 "pxfm",
]

[[package]]
name = "mu"
version = "0.1.0"
dependencies = [
 "anyhow",
 "arboard",
 "clap",
 "notify",
 "notify-debouncer-mini",
 "serde",
 "serde_json",
 "tiktoken-rs",
 "walkdir",
]

[[package]]
name = "notify"
version = "6.1.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6205bd8bb1e454ad2e27422015fb5e4f2bcc7e08fa8f27058670d208324a4d2d"
dependencies = [
 "bitflags 2.10.0",
 "crossbeam-channel",
 "filetime",
 "fsevent-sys",
 "inotify",
 "kqueue",
 "libc",
 "log",
 "mio",
 "walkdir",
 "windows-sys 0.48.0",
]

[[package]]
name = "notify-debouncer-mini"
version = "0.4.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5d40b221972a1fc5ef4d858a2f671fb34c75983eb385463dff3780eeff6a9d43"
dependencies = [
 "crossbeam-channel",
 "log",
 "notify",
]

[[package]]
name = "num-traits"
version = "0.2.19"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "071dfc062690e90b734c0b2273ce72ad0ffa95f0c74596bc250dcfd960262841"
dependencies = [
 "autocfg",
]

[[package]]
name = "objc2"
version = "0.6.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b7c2599ce0ec54857b29ce62166b0ed9b4f6f1a70ccc9a71165b6154caca8c05"
dependencies = [
 "objc2-encode",
]

[[package]]
name = "objc2-app-kit"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d49e936b501e5c5bf01fda3a9452ff86dc3ea98ad5f283e1455153142d97518c"
dependencies = [
 "bitflags 2.10.0",
 "objc2",
 "objc2-core-graphics",
 "objc2-foundation",
]

[[package]]
name = "objc2-core-foundation"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2a180dd8642fa45cdb7dd721cd4c11b1cadd4929ce112ebd8b9f5803cc79d536"
dependencies = [
 "bitflags 2.10.0",
 "dispatch2",
 "objc2",
]

[[package]]
name = "objc2-core-graphics"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e022c9d066895efa1345f8e33e584b9f958da2fd4cd116792e15e07e4720a807"
dependencies = [
 "bitflags 2.10.0",
 "dispatch2",
 "objc2",
 "objc2-core-foundation",
 "objc2-io-surface",
]

[[package]]
name = "objc2-encode"
version = "4.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ef25abbcd74fb2609453eb695bd2f860d389e457f67dc17cafc8b8cbc89d0c33"

[[package]]
name = "objc2-foundation"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e3e0adef53c21f888deb4fa59fc59f7eb17404926ee8a6f59f5df0fd7f9f3272"
dependencies = [
 "bitflags 2.10.0",
 "objc2",
 "objc2-core-foundation",
]

[[package]]
name = "objc2-io-surface"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "180788110936d59bab6bd83b6060ffdfffb3b922ba1396b312ae795e1de9d81d"
dependencies = [
 "bitflags 2.10.0",
 "objc2",
 "objc2-core-foundation",
]

[[package]]
name = "once_cell_polyfill"
version = "1.70.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "384b8ab6d37215f3c5301a95a4accb5d64aa607f1fcb26a11b5303878451b4fe"

[[package]]
name = "parking_lot"
version = "0.12.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "93857453250e3077bd71ff98b6a65ea6621a19bb0f559a85248955ac12c45a1a"
dependencies = [
 "lock_api",
 "parking_lot_core",
]

[[package]]
name = "parking_lot_core"
version = "0.9.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2621685985a2ebf1c516881c026032ac7deafcda1a2c9b7850dc81e3dfcb64c1"
dependencies = [
 "cfg-if",
 "libc",
 "redox_syscall 0.5.18",
 "smallvec",
 "windows-link",
]

[[package]]
name = "percent-encoding"
version = "2.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9b4f627cb1b25917193a259e49bdad08f671f8d9708acfd5fe0a8c1455d87220"

[[package]]
name = "png"
version = "0.18.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "97baced388464909d42d89643fe4361939af9b7ce7a31ee32a168f832a70f2a0"
dependencies = [
 "bitflags 2.10.0",
 "crc32fast",
 "fdeflate",
 "flate2",
 "miniz_oxide",
]

[[package]]
name = "proc-macro2"
version = "1.0.103"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5ee95bc4ef87b8d5ba32e8b7714ccc834865276eab0aed5c9958d00ec45f49e8"
dependencies = [
 "unicode-ident",
]

[[package]]
name = "pxfm"
version = "0.1.27"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7186d3822593aa4393561d186d1393b3923e9d6163d3fbfd6e825e3e6cf3e6a8"
dependencies = [
 "num-traits",
]

[[package]]
name = "quick-error"
version = "2.0.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a993555f31e5a609f617c12db6250dedcac1b0a85076912c436e6fc9b2c8e6a3"

[[package]]
name = "quote"
version = "1.0.42"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a338cc41d27e6cc6dce6cefc13a0729dfbb81c262b1f519331575dd80ef3067f"
dependencies = [
 "proc-macro2",
]

[[package]]
name = "redox_syscall"
version = "0.5.18"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ed2bf2547551a7053d6fdfafda3f938979645c44812fbfcda098faae3f1a362d"
dependencies = [
 "bitflags 2.10.0",
]

[[package]]
name = "redox_syscall"
version = "0.6.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ec96166dafa0886eb81fe1c0a388bece180fbef2135f97c1e2cf8302e74b43b5"
dependencies = [
 "bitflags 2.10.0",
]

[[package]]
name = "regex"
version = "1.12.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "843bc0191f75f3e22651ae5f1e72939ab2f72a4bc30fa80a066bd66edefc24d4"
dependencies = [
 "aho-corasick",
 "memchr",
 "regex-automata",
 "regex-syntax",
]

[[package]]
name = "regex-automata"
version = "0.4.13"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5276caf25ac86c8d810222b3dbb938e512c55c6831a10f3e6ed1c93b84041f1c"
dependencies = [
 "aho-corasick",
 "memchr",
 "regex-syntax",
]

[[package]]
name = "regex-syntax"
version = "0.8.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7a2d987857b319362043e95f5353c0535c1f58eec5336fdfcf626430af7def58"

[[package]]
name = "rustc-hash"
version = "1.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "08d43f7aa6b08d49f382cde6a7982047c3426db949b1424bc4b7ec9ae12c6ce2"

[[package]]
name = "rustix"
version = "1.1.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cd15f8a2c5551a84d56efdc1cd049089e409ac19a3072d5037a17fd70719ff3e"
dependencies = [
 "bitflags 2.10.0",
 "errno",
 "libc",
 "linux-raw-sys",
 "windows-sys 0.61.2",
]

[[package]]
name = "ryu"
version = "1.0.20"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "28d3b2b1366ec20994f1fd18c3c594f05c5dd4bc44d8bb0c1c632c8d6829481f"

[[package]]
name = "same-file"
version = "1.0.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "93fc1dc3aaa9bfed95e02e6eadabb4baf7e3078b0bd1b4d7b6b0b68378900502"
dependencies = [
 "winapi-util",
]

[[package]]
name = "scopeguard"
version = "1.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "94143f37725109f92c262ed2cf5e59bce7498c01bcc1502d7b9afe439a4e9f49"

[[package]]
name = "serde"
version = "1.0.228"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9a8e94ea7f378bd32cbbd37198a4a91436180c5bb472411e48b5ec2e2124ae9e"
dependencies = [
 "serde_core",
 "serde_derive",
]

[[package]]
name = "serde_core"
version = "1.0.228"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "41d385c7d4ca58e59fc732af25c3983b67ac852c1a25000afe1175de458b67ad"
dependencies = [
 "serde_derive",
]

[[package]]
name = "serde_derive"
version = "1.0.228"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d540f220d3187173da220f885ab66608367b6574e925011a9353e4badda91d79"
dependencies = [
 "proc-macro2",
 "quote",
 "syn",
]

[[package]]
name = "serde_json"
version = "1.0.145"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "402a6f66d8c709116cf22f558eab210f5a50187f702eb4d7e5ef38d9a7f1c79c"
dependencies = [
 "itoa",
 "memchr",
 "ryu",
 "serde",
 "serde_core",
]

[[package]]
name = "simd-adler32"
version = "0.3.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e320a6c5ad31d271ad523dcf3ad13e2767ad8b1cb8f047f75a8aeaf8da139da2"

[[package]]
name = "smallvec"
version = "1.15.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "67b1b7a3b5fe4f1376887184045fcf45c69e92af734b7aaddc05fb777b6fbd03"

[[package]]
name = "strsim"
version = "0.11.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7da8b5736845d9f2fcb837ea5d9e2628564b3b043a70948a3f0b778838c5fb4f"

[[package]]
name = "syn"
version = "2.0.111"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "390cc9a294ab71bdb1aa2e99d13be9c753cd2d7bd6560c77118597410c4d2e87"
dependencies = [
 "proc-macro2",
 "quote",
 "unicode-ident",
]

[[package]]
name = "tiff"
version = "0.10.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "af9605de7fee8d9551863fd692cce7637f548dbd9db9180fcc07ccc6d26c336f"
dependencies = [
 "fax",
 "flate2",
 "half",
 "quick-error",
 "weezl",
 "zune-jpeg",
]

[[package]]
name = "tiktoken-rs"
version = "0.5.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c314e7ce51440f9e8f5a497394682a57b7c323d0f4d0a6b1b13c429056e0e234"
dependencies = [
 "anyhow",
 "base64",
 "bstr",
 "fancy-regex",
 "lazy_static",
 "parking_lot",
 "rustc-hash",
]

[[package]]
name = "unicode-ident"
version = "1.0.22"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9312f7c4f6ff9069b165498234ce8be658059c6728633667c526e27dc2cf1df5"

[[package]]
name = "utf8parse"
version = "0.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "06abde3611657adf66d383f00b093d7faecc7fa57071cce2578660c9f1010821"

[[package]]
name = "walkdir"
version = "2.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "29790946404f91d9c5d06f9874efddea1dc06c5efe94541a7d6863108e3a5e4b"
dependencies = [
 "same-file",
 "winapi-util",
]

[[package]]
name = "wasi"
version = "0.11.1+wasi-snapshot-preview1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ccf3ec651a847eb01de73ccad15eb7d99f80485de043efb2f370cd654f4ea44b"

[[package]]
name = "weezl"
version = "0.1.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a28ac98ddc8b9274cb41bb4d9d4d5c425b6020c50c46f25559911905610b4a88"

[[package]]
name = "winapi-util"
version = "0.1.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c2a7b1c03c876122aa43f3020e6c3c3ee5c05081c9a00739faf7503aeba10d22"
dependencies = [
 "windows-sys 0.61.2",
]

[[package]]
name = "windows-link"
version = "0.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f0805222e57f7521d6a62e36fa9163bc891acd422f971defe97d64e70d0a4fe5"

[[package]]
name = "windows-sys"
version = "0.48.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "677d2418bec65e3338edb076e806bc1ec15693c5d0104683f2efe857f61056a9"
dependencies = [
 "windows-targets 0.48.5",
]

[[package]]
name = "windows-sys"
version = "0.60.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f2f500e4d28234f72040990ec9d39e3a6b950f9f22d3dba18416c35882612bcb"
dependencies = [
 "windows-targets 0.53.5",
]

[[package]]
name = "windows-sys"
version = "0.61.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ae137229bcbd6cdf0f7b80a31df61766145077ddf49416a728b02cb3921ff3fc"
dependencies = [
 "windows-link",
]

[[package]]
name = "windows-targets"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9a2fa6e2155d7247be68c096456083145c183cbbbc2764150dda45a87197940c"
dependencies = [
 "windows_aarch64_gnullvm 0.48.5",
 "windows_aarch64_msvc 0.48.5",
 "windows_i686_gnu 0.48.5",
 "windows_i686_msvc 0.48.5",
 "windows_x86_64_gnu 0.48.5",
 "windows_x86_64_gnullvm 0.48.5",
 "windows_x86_64_msvc 0.48.5",
]

[[package]]
name = "windows-targets"
version = "0.53.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4945f9f551b88e0d65f3db0bc25c33b8acea4d9e41163edf90dcd0b19f9069f3"
dependencies = [
 "windows-link",
 "windows_aarch64_gnullvm 0.53.1",
 "windows_aarch64_msvc 0.53.1",
 "windows_i686_gnu 0.53.1",
 "windows_i686_gnullvm",
 "windows_i686_msvc 0.53.1",
 "windows_x86_64_gnu 0.53.1",
 "windows_x86_64_gnullvm 0.53.1",
 "windows_x86_64_msvc 0.53.1",
]

[[package]]
name = "windows_aarch64_gnullvm"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2b38e32f0abccf9987a4e3079dfb67dcd799fb61361e53e2882c3cbaf0d905d8"

[[package]]
name = "windows_aarch64_gnullvm"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a9d8416fa8b42f5c947f8482c43e7d89e73a173cead56d044f6a56104a6d1b53"

[[package]]
name = "windows_aarch64_msvc"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "dc35310971f3b2dbbf3f0690a219f40e2d9afcf64f9ab7cc1be722937c26b4bc"

[[package]]
name = "windows_aarch64_msvc"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b9d782e804c2f632e395708e99a94275910eb9100b2114651e04744e9b125006"

[[package]]
name = "windows_i686_gnu"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a75915e7def60c94dcef72200b9a8e58e5091744960da64ec734a6c6e9b3743e"

[[package]]
name = "windows_i686_gnu"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "960e6da069d81e09becb0ca57a65220ddff016ff2d6af6a223cf372a506593a3"

[[package]]
name = "windows_i686_gnullvm"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fa7359d10048f68ab8b09fa71c3daccfb0e9b559aed648a8f95469c27057180c"

[[package]]
name = "windows_i686_msvc"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8f55c233f70c4b27f66c523580f78f1004e8b5a8b659e05a4eb49d4166cca406"

[[package]]
name = "windows_i686_msvc"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1e7ac75179f18232fe9c285163565a57ef8d3c89254a30685b57d83a38d326c2"

[[package]]
name = "windows_x86_64_gnu"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "53d40abd2583d23e4718fddf1ebec84dbff8381c07cae67ff7768bbf19c6718e"

[[package]]
name = "windows_x86_64_gnu"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9c3842cdd74a865a8066ab39c8a7a473c0778a3f29370b5fd6b4b9aa7df4a499"

[[package]]
name = "windows_x86_64_gnullvm"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0b7b52767868a23d5bab768e390dc5f5c55825b6d30b86c844ff2dc7414044cc"

[[package]]
name = "windows_x86_64_gnullvm"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0ffa179e2d07eee8ad8f57493436566c7cc30ac536a3379fdf008f47f6bb7ae1"

[[package]]
name = "windows_x86_64_msvc"
version = "0.48.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ed94fce61571a4006852b7389a063ab983c02eb1bb37b47f8272ce92d06d9538"

[[package]]
name = "windows_x86_64_msvc"
version = "0.53.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d6bbff5f0aada427a1e5a6da5f1f98158182f26556f345ac9e04d36d0ebed650"

[[package]]
name = "x11rb"
version = "0.13.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9993aa5be5a26815fe2c3eacfc1fde061fc1a1f094bf1ad2a18bf9c495dd7414"
dependencies = [
 "gethostname",
 "rustix",
 "x11rb-protocol",
]

[[package]]
name = "x11rb-protocol"
version = "0.13.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ea6fc2961e4ef194dcbfe56bb845534d0dc8098940c7e5c012a258bfec6701bd"

[[package]]
name = "zerocopy"
version = "0.8.31"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fd74ec98b9250adb3ca554bdde269adf631549f51d8a8f8f0a10b50f1cb298c3"
dependencies = [
 "zerocopy-derive",
]

[[package]]
name = "zerocopy-derive"
version = "0.8.31"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d8a8d209fdf45cf5138cbb5a506f6b52522a25afccc534d1475dad8e31105c6a"
dependencies = [
 "proc-macro2",
 "quote",
 "syn",
]

[[package]]
name = "zune-core"
version = "0.4.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3f423a2c17029964870cfaabb1f13dfab7d092a62a29a89264f4d36990ca414a"

[[package]]
name = "zune-jpeg"
version = "0.4.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "29ce2c8a9384ad323cf564b67da86e21d3cfdff87908bc1223ed5c99bc792713"
dependencies = [
 "zune-core",
]
```

### mu/Cargo.toml

```toml
[package]
name = "mu"
version = "0.1.0"
edition = "2021"
description = "Memory Unit - Deterministic codebase mapper for AI context injection"
authors = ["Your Name"]

[dependencies]
clap = { version = "4.4", features = ["derive"] }
walkdir = "2.4"
notify = { version = "6.1", features = ["macos_kqueue"] }
notify-debouncer-mini = "0.4"
anyhow = "1.0"
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
tiktoken-rs = "0.5"
arboard = "3.2"

[profile.release]
opt-level = 3
lto = true
codegen-units = 1
strip = true
```

### mu/README.md

```md
# mu (Memory Unit)

A blazing-fast CLI tool that creates a deterministic map of your codebase for AI context injection.

## Installation

```bash
cd mu
cargo build --release
```

Binary will be at `target/release/mu.exe` (Windows) or `target/release/mu` (Unix).

## Usage

```bash
# Generate context.xml from current directory
mu

# Watch mode - auto-regenerates on file changes
mu watch
```

## Output

Generates `context.xml` in the current directory:

```xml
<project_map>
<file path="src/main.rs">
[file content]
</file>
<file path="README.md">
[file content]
</file>
</project_map>
```

## Features

- Deterministic output (sorted paths)
- Auto-ignores junk: `.git`, `node_modules`, `target`, `dist`, `build`, `__pycache__`, etc.
- Skips binary files (null-byte detection)
- Proper XML escaping
- Watch mode with 200ms debounce
- UTF-8 text files only

## License

MIT
```

### mu/src/formatter.rs

```rs
use crate::memory::{FileEntry, Memory};
use tiktoken_rs::cl100k_base;

#[derive(Debug, Clone, Copy, Default)]
pub enum OutputTarget {
    #[default]
    Raw,
    Claude,
    Cursor,
}

impl std::str::FromStr for OutputTarget {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "raw" => Ok(Self::Raw),
            "claude" => Ok(Self::Claude),
            "cursor" => Ok(Self::Cursor),
            _ => Err(format!("Unknown target: {}. Use: raw, claude, cursor", s)),
        }
    }
}

pub trait Formatter {
    fn format(&self, memory: &Memory) -> String;
    fn extension(&self) -> &'static str;
}

pub struct RawFormatter;
pub struct ClaudeFormatter;
pub struct CursorFormatter;

/// Estimate token count using cl100k_base (GPT-4/Claude tokenizer)
pub fn estimate_tokens(text: &str) -> usize {
    cl100k_base()
        .map(|bpe| bpe.encode_with_special_tokens(text).len())
        .unwrap_or_else(|_| text.len() / 4) // Fallback: ~4 chars per token
}

/// Format token count for display
pub fn format_token_count(tokens: usize) -> String {
    if tokens >= 1_000_000 {
        format!("~{:.1}M tokens", tokens as f64 / 1_000_000.0)
    } else if tokens >= 1_000 {
        format!("~{:.1}k tokens", tokens as f64 / 1_000.0)
    } else {
        format!("~{} tokens", tokens)
    }
}

impl Formatter for RawFormatter {
    fn format(&self, memory: &Memory) -> String {
        serde_json::to_string_pretty(&memory.files).unwrap_or_default()
    }
    
    fn extension(&self) -> &'static str {
        "json"
    }
}

impl Formatter for ClaudeFormatter {
    fn format(&self, memory: &Memory) -> String {
        let mut out = String::new();
        out.push_str("<context>\n");
        out.push_str("<project_map>\n");
        
        let mut entries: Vec<&FileEntry> = memory.files.values().collect();
        entries.sort_by(|a, b| a.path.cmp(&b.path));
        
        for entry in entries {
            out.push_str(&format!("<file path=\"{}\">\n", escape_xml(&entry.path)));
            out.push_str(&escape_xml(&entry.content));
            if !entry.content.ends_with('\n') {
                out.push('\n');
            }
            out.push_str("</file>\n");
        }
        
        out.push_str("</project_map>\n");
        out.push_str("</context>");
        out
    }
    
    fn extension(&self) -> &'static str {
        "xml"
    }
}

impl Formatter for CursorFormatter {
    fn format(&self, memory: &Memory) -> String {
        let mut out = String::new();
        out.push_str("# Project Context\n\n");
        out.push_str("## File Structure\n\n");
        
        let mut entries: Vec<&FileEntry> = memory.files.values().collect();
        entries.sort_by(|a, b| a.path.cmp(&b.path));
        
        // Tree view
        for entry in &entries {
            out.push_str(&format!("- `{}`\n", entry.path));
        }
        
        out.push_str("\n## File Contents\n\n");
        
        for entry in entries {
            let ext = entry.path.rsplit('.').next().unwrap_or("txt");
            out.push_str(&format!("### {}\n\n```{}\n", entry.path, ext));
            out.push_str(&entry.content);
            if !entry.content.ends_with('\n') {
                out.push('\n');
            }
            out.push_str("```\n\n");
        }
        
        out
    }
    
    fn extension(&self) -> &'static str {
        "md"
    }
}

pub fn get_formatter(target: OutputTarget) -> Box<dyn Formatter> {
    match target {
        OutputTarget::Raw => Box::new(RawFormatter),
        OutputTarget::Claude => Box::new(ClaudeFormatter),
        OutputTarget::Cursor => Box::new(CursorFormatter),
    }
}

fn escape_xml(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}
```

### mu/src/main.rs

```rs
mod formatter;
mod memory;
mod scanner;
mod sync;

use anyhow::{Context, Result};
use arboard::Clipboard;
use clap::{Parser, Subcommand, ValueEnum};
use formatter::{estimate_tokens, format_token_count, get_formatter, OutputTarget};
use memory::Memory;
use notify_debouncer_mini::{new_debouncer, notify::RecursiveMode, DebouncedEventKind};
use scanner::is_ignored_path;
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::Path;
use std::sync::mpsc::channel;
use std::time::Duration;
use sync::SyncService;

#[derive(Parser)]
#[command(name = "mu")]
#[command(about = "Memory Unit - Deterministic codebase mapper for AI context injection")]
#[command(version)]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,

    /// Output format target
    #[arg(short, long, default_value = "claude")]
    target: Target,

    /// Copy output to clipboard automatically
    #[arg(short, long)]
    copy: bool,
}

#[derive(Clone, ValueEnum, Default)]
enum Target {
    /// Raw JSON dump
    Raw,
    /// XML optimized for Claude/Anthropic caching
    #[default]
    Claude,
    /// Markdown for Cursor chat/rules
    Cursor,
}

impl From<Target> for OutputTarget {
    fn from(t: Target) -> Self {
        match t {
            Target::Raw => OutputTarget::Raw,
            Target::Claude => OutputTarget::Claude,
            Target::Cursor => OutputTarget::Cursor,
        }
    }
}

#[derive(Subcommand)]
enum Commands {
    /// Watch for file changes and auto-regenerate context
    Watch,
    /// Incremental sync - only update changed files
    Sync,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let root = std::env::current_dir().context("Failed to get current directory")?;
    let target: OutputTarget = cli.target.into();

    match cli.command {
        Some(Commands::Watch) => watch_mode(&root, target, cli.copy),
        Some(Commands::Sync) => sync_mode(&root, target, cli.copy),
        None => full_scan(&root, target, cli.copy),
    }
}

fn full_scan(root: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    let service = SyncService::new(root);
    let memory = service.full_scan()?;

    memory.save(root)?;
    let output = write_output(root, &memory, target)?;

    let tokens = estimate_tokens(&output);
    println!(
        "✓ Generated context ({} files, {})",
        memory.files.len(),
        format_token_count(tokens)
    );

    if copy {
        copy_to_clipboard(&output)?;
    }

    Ok(())
}

fn sync_mode(root: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    let service = SyncService::new(root);
    let existing = Memory::load(root).unwrap_or_default();

    let memory = service.incremental_sync(existing)?;

    memory.save(root)?;
    let output = write_output(root, &memory, target)?;

    let tokens = estimate_tokens(&output);
    println!(
        "✓ Synced context ({} files, {})",
        memory.files.len(),
        format_token_count(tokens)
    );

    if copy {
        copy_to_clipboard(&output)?;
    }

    Ok(())
}

fn watch_mode(root: &Path, target: OutputTarget, copy: bool) -> Result<()> {
    println!("👁 Watching for changes... (Ctrl+C to stop)");

    let service = SyncService::new(root);
    let mut memory = service.full_scan()?;
    memory.save(root)?;
    let output = write_output(root, &memory, target)?;

    let tokens = estimate_tokens(&output);
    println!(
        "✓ Initial context ({} files, {})",
        memory.files.len(),
        format_token_count(tokens)
    );

    if copy {
        copy_to_clipboard(&output)?;
    }

    let (tx, rx) = channel();
    let mut debouncer = new_debouncer(Duration::from_millis(200), tx)?;
    debouncer.watcher().watch(root, RecursiveMode::Recursive)?;

    let formatter = get_formatter(target);
    let output_name = format!("context.{}", formatter.extension());

    loop {
        match rx.recv() {
            Ok(Ok(events)) => {
                let relevant = events.iter().any(|e| {
                    e.kind == DebouncedEventKind::Any
                        && !e.path.ends_with(&output_name)
                        && !e.path.ends_with(".mu_memory.json")
                        && !is_ignored_path(&e.path)
                });

                if relevant {
                    match service.incremental_sync(memory.clone()) {
                        Ok(new_memory) => {
                            memory = new_memory;
                            let _ = memory.save(root);
                            if let Ok(out) = write_output(root, &memory, target) {
                                let tokens = estimate_tokens(&out);
                                println!(
                                    "✓ Synced ({} files, {})",
                                    memory.files.len(),
                                    format_token_count(tokens)
                                );
                                if copy {
                                    let _ = copy_to_clipboard(&out);
                                }
                            }
                        }
                        Err(e) => eprintln!("✗ Error: {}", e),
                    }
                }
            }
            Ok(Err(e)) => eprintln!("Watch error: {:?}", e),
            Err(e) => {
                eprintln!("Channel error: {}", e);
                break;
            }
        }
    }

    Ok(())
}

fn write_output(root: &Path, memory: &Memory, target: OutputTarget) -> Result<String> {
    let formatter = get_formatter(target);
    let output = formatter.format(memory);
    let filename = format!("context.{}", formatter.extension());
    let path = root.join(&filename);

    let file = File::create(&path)?;
    let mut writer = BufWriter::new(file);
    write!(writer, "{}", output)?;
    writer.flush()?;

    Ok(output)
}

fn copy_to_clipboard(content: &str) -> Result<()> {
    match Clipboard::new() {
        Ok(mut clipboard) => {
            clipboard
                .set_text(content.to_string())
                .context("Failed to copy to clipboard")?;
            println!("📋 Copied to clipboard");
            Ok(())
        }
        Err(e) => {
            eprintln!("⚠ Clipboard unavailable: {}", e);
            Ok(())
        }
    }
}
```

### mu/src/memory.rs

```rs
use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::SystemTime;

const MEMORY_FILE: &str = ".mu_memory.json";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileEntry {
    pub path: String,
    pub content: String,
    pub modified: u64,
    pub hash: u64,
}

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct Memory {
    pub version: u32,
    pub files: HashMap<String, FileEntry>,
    pub last_sync: u64,
}

impl Memory {
    pub fn load(root: &Path) -> Result<Self> {
        let path = root.join(MEMORY_FILE);
        if path.exists() {
            let data = fs::read_to_string(&path)?;
            Ok(serde_json::from_str(&data)?)
        } else {
            Ok(Self::default())
        }
    }

    pub fn save(&self, root: &Path) -> Result<()> {
        let path = root.join(MEMORY_FILE);
        let data = serde_json::to_string_pretty(self)?;
        fs::write(path, data)?;
        Ok(())
    }

    pub fn get_dirty_files(&self, current_files: &[(PathBuf, u64)]) -> Vec<PathBuf> {
        let mut dirty = Vec::new();
        
        for (path, modified) in current_files {
            let rel_path = path.to_string_lossy().replace('\\', "/");
            match self.files.get(&rel_path) {
                Some(entry) if entry.modified >= *modified => continue,
                _ => dirty.push(path.clone()),
            }
        }
        dirty
    }

    pub fn patch(&mut self, updates: Vec<FileEntry>) {
        for entry in updates {
            self.files.insert(entry.path.clone(), entry);
        }
        self.last_sync = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
    }

    pub fn remove_deleted(&mut self, existing_paths: &[String]) {
        let existing: std::collections::HashSet<_> = existing_paths.iter().collect();
        self.files.retain(|k, _| existing.contains(k));
    }
}

pub fn hash_content(content: &str) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    content.hash(&mut hasher);
    hasher.finish()
}
```

### mu/src/scanner.rs

```rs
use anyhow::Result;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use walkdir::WalkDir;

pub const IGNORED_DIRS: &[&str] = &[
    "node_modules",
    ".git",
    "target",
    "dist",
    "vendor",
    ".next",
    "build",
    ".env",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "coverage",
    ".nuxt",
];

// SECURITY: Hard-blocked files - NEVER include these
pub const IGNORED_FILES: &[&str] = &[
    // System
    ".DS_Store",
    // Secrets & credentials
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
    "id_rsa",
    "id_rsa.pub",
    "id_ed25519",
    "id_ed25519.pub",
    "id_dsa",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "secrets.yaml",
    "secrets.yml",
    "secrets.json",
    ".npmrc",
    ".pypirc",
    "credentials",
    "credentials.json",
    "service-account.json",
    // Output files
    "context.xml",
    "context.json",
    "context.md",
    ".mu_memory.json",
];

// Patterns for extension-based blocking
pub const BLOCKED_EXTENSIONS: &[&str] = &[
    "pem", "key", "p12", "pfx", "jks", "keystore",
];

pub const BLOCKED_PATTERNS: &[&str] = &[
    "id_rsa", "id_dsa", "id_ed25519", "id_ecdsa",
    "aws_access", "aws_secret", "credentials",
];

pub fn scan_files(root: &Path) -> Result<Vec<PathBuf>> {
    let ignored_dirs: HashSet<&str> = IGNORED_DIRS.iter().copied().collect();
    let ignored_files: HashSet<&str> = IGNORED_FILES.iter().copied().collect();

    let mut entries: Vec<PathBuf> = WalkDir::new(root)
        .into_iter()
        .filter_entry(|e| !should_skip_dir(e, &ignored_dirs))
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .filter(|e| !is_blocked_file(e.path(), &ignored_files))
        .map(|e| e.into_path())
        .collect();

    entries.sort();
    Ok(entries)
}

fn is_blocked_file(path: &Path, ignored_files: &HashSet<&str>) -> bool {
    let filename = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
    
    // Direct filename match
    if ignored_files.contains(filename) {
        return true;
    }
    
    // Extension-based blocking
    if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
        if BLOCKED_EXTENSIONS.contains(&ext) {
            return true;
        }
    }
    
    // Pattern-based blocking (contains check)
    let lower = filename.to_lowercase();
    for pattern in BLOCKED_PATTERNS {
        if lower.contains(pattern) {
            return true;
        }
    }
    
    false
}

fn should_skip_dir(entry: &walkdir::DirEntry, ignored: &HashSet<&str>) -> bool {
    entry
        .file_name()
        .to_str()
        .map(|s| ignored.contains(s))
        .unwrap_or(false)
}

pub fn is_ignored_path(path: &Path) -> bool {
    path.components().any(|c| {
        c.as_os_str()
            .to_str()
            .map(|s| IGNORED_DIRS.contains(&s) || IGNORED_FILES.contains(&s))
            .unwrap_or(false)
    })
}
```

### mu/src/sync.rs

```rs
use crate::memory::{hash_content, FileEntry, Memory};
use crate::scanner::scan_files;
use anyhow::Result;
use std::fs;
use std::path::Path;
use std::time::SystemTime;

pub struct SyncService {
    root: std::path::PathBuf,
}

impl SyncService {
    pub fn new(root: &Path) -> Self {
        Self {
            root: root.to_path_buf(),
        }
    }

    /// Full scan - builds memory from scratch
    pub fn full_scan(&self) -> Result<Memory> {
        let mut memory = Memory::default();
        memory.version = 1;

        let files = scan_files(&self.root)?;
        let entries = self.parse_files(&files);
        memory.patch(entries);

        Ok(memory)
    }

    /// Incremental sync - only updates dirty files
    pub fn incremental_sync(&self, mut memory: Memory) -> Result<Memory> {
        let files = scan_files(&self.root)?;
        
        // Get file paths with modification times
        let current: Vec<_> = files
            .iter()
            .filter_map(|p| {
                let modified = fs::metadata(p)
                    .and_then(|m| m.modified())
                    .ok()?
                    .duration_since(SystemTime::UNIX_EPOCH)
                    .ok()?
                    .as_secs();
                Some((p.clone(), modified))
            })
            .collect();

        // Find dirty files
        let dirty = memory.get_dirty_files(&current);
        
        if dirty.is_empty() {
            println!("✓ No changes detected");
            return Ok(memory);
        }

        println!("⟳ Syncing {} changed file(s)...", dirty.len());
        
        // Parse only dirty files
        let updates = self.parse_files(&dirty);
        memory.patch(updates);

        // Remove deleted files
        let existing: Vec<String> = current
            .iter()
            .map(|(p, _)| {
                p.strip_prefix(&self.root)
                    .unwrap_or(p)
                    .to_string_lossy()
                    .replace('\\', "/")
            })
            .collect();
        memory.remove_deleted(&existing);

        Ok(memory)
    }

    fn parse_files(&self, files: &[std::path::PathBuf]) -> Vec<FileEntry> {
        files
            .iter()
            .filter_map(|path| {
                let content = read_text_file(path)?;
                let modified = fs::metadata(path)
                    .and_then(|m| m.modified())
                    .ok()?
                    .duration_since(SystemTime::UNIX_EPOCH)
                    .ok()?
                    .as_secs();

                let rel_path = path
                    .strip_prefix(&self.root)
                    .unwrap_or(path)
                    .to_string_lossy()
                    .replace('\\', "/");

                Some(FileEntry {
                    path: rel_path,
                    content: content.clone(),
                    modified,
                    hash: hash_content(&content),
                })
            })
            .collect()
    }
}

fn read_text_file(path: &Path) -> Option<String> {
    let content = fs::read(path).ok()?;
    let check_len = content.len().min(8192);
    if content[..check_len].contains(&0) {
        return None;
    }
    String::from_utf8(content).ok()
}
```

### requirements.txt

```txt
openai>=1.0.0
```

### state_key.md

```md
```markdown
## State Snapshot

1. Active architectural patterns:
   - REST API
   - Clean architecture

2. Negative constraints:
   - None specified in the conversation

3. User stylistic preferences:
   - Use of FastAPI for building the REST API
```
```

### verify_ignore.py

```py
import os
import shutil
import subprocess
import sys

TEST_DIR = "test_env"
OUTPUT_FILE = "context.xml"

def setup():
    # Clean up any previous test
    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)
    
    # Create test structure
    os.makedirs(os.path.join(TEST_DIR, "src"))
    os.makedirs(os.path.join(TEST_DIR, "node_modules"))
    
    # Create dummy files
    with open(os.path.join(TEST_DIR, "src", "main.ts"), "w") as f:
        f.write("// Main entry point\nconsole.log('hello');")
    
    with open(os.path.join(TEST_DIR, "node_modules", "bloat.ts"), "w") as f:
        f.write("// This should be ignored\nexport const bloat = true;")

def build():
    print("Building mu binary...")
    result = subprocess.run(
        ["cargo", "build", "--release"],
        cwd="mu",
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print(f"Build failed:\n{result.stderr}")
        sys.exit(1)
    print("Build successful.")

def execute():
    print("Running mu against test_env...")
    binary = os.path.join("mu", "target", "release", "mu.exe")
    if not os.path.exists(binary):
        binary = os.path.join("mu", "target", "release", "mu")
    
    result = subprocess.run(
        [binary],
        cwd=TEST_DIR,
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print(f"Execution failed:\n{result.stderr}")
        sys.exit(1)
    print("Execution successful.")

def verify():
    output_path = os.path.join(TEST_DIR, OUTPUT_FILE)
    
    if not os.path.exists(output_path):
        print(f"❌ TEST FAILED: {OUTPUT_FILE} not generated")
        return False
    
    with open(output_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    has_main = "src/main.ts" in content
    has_bloat = "node_modules/bloat.ts" in content
    
    if has_main and not has_bloat:
        print("✅ TEST PASSED: node_modules successfully ignored")
        return True
    else:
        print("❌ TEST FAILED")
        if not has_main:
            print("   - src/main.ts was NOT found (should be present)")
        if has_bloat:
            print("   - node_modules/bloat.ts WAS found (should be ignored)")
        return False

def cleanup():
    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)

if __name__ == "__main__":
    try:
        setup()
        build()
        execute()
        success = verify()
        cleanup()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"❌ TEST ERROR: {e}")
        cleanup()
        sys.exit(1)
```

