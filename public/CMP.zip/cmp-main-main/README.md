# CMP (Context Memory Protocol) - Beta v0.3

CMP is a local "State Injection" layer designed to solve Context Amnesia in long LLM sessions.

## The Problem

LLMs treat every session as a fresh start. "Project Prompts" are static and expensive.

CMP creates a dynamic **State Key** that captures architectural decisions, negative constraints, and active variables from your previous session.

## Components

### mu (Memory Unit) - Rust CLI

A blazing-fast codebase mapper that generates deterministic XML snapshots for AI context windows.

```bash
# Build
cd mu && cargo build --release

# Generate context.xml
./mu/target/release/mu

# Watch mode (auto-regenerates on changes)
./mu/target/release/mu watch
```

Output format:
```xml
<project_map>
  <file path="src/main.rs">[content]</file>
  <file path="README.md">[content]</file>
</project_map>
```

Features:
- Deterministic output (sorted paths)
- Auto-ignores: `.git`, `node_modules`, `target`, `dist`, `build`, `__pycache__`
- Skips binary files
- Watch mode with 200ms debounce

### Compressor (`compressor.py`)

Uses `mu` for dependency analysis and extracts structured snapshots of your current focus.

### Injector (`injector.py`)

Formats the State Key into an XML block optimized for Claude/GPT system prompts.

## Quick Start

```bash
# Option 1: Full codebase map
./mu/target/release/mu

# Option 2: Targeted dependency analysis
python compressor.py <target_file_or_node>
python injector.py
```

Paste the output into your new chat to restore context.

## Ignored Directories

The `mu` CLI automatically skips these directories at the iterator level to prevent memory crashes on large projects:

- `node_modules`
- `.git`
- `target`
- `dist`
- `vendor`
- `.next`
- `build`, `__pycache__`, `.venv`, `venv`, `.idea`, `.vscode`, `coverage`, `.nuxt`

This filter is hard-coded and overrides any user config.

## Security

- Runs 100% locally
- No LLM calls required for compression
- No data sent to external servers

## Support

- Email: justinlord@empusaai.com
- X: @justin_lords
