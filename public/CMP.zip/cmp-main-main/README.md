# CMP (Context Memory Protocol)

Stop explaining your codebase. Just build.

CMP is a blazing-fast, deterministic context engine for AI-assisted development. It solves "Context Rot" by generating lightweight, token-optimized maps of your entire repository without burning your API credits or flooding your clipboard with noise.

Built in Rust for instant performance on projects of any size.

---

## Installation

```bash
# Build
cd cmp
cargo build --release

# Add to PATH (run once)
# Windows PowerShell:
$binPath = "$env:USERPROFILE\.local\bin"
New-Item -ItemType Directory -Path $binPath -Force
Copy-Item ".\target\release\cmp.exe" "$binPath\cmp.exe"
[Environment]::SetEnvironmentVariable("PATH", "$env:PATH;$binPath", [EnvironmentVariableTarget]::User)

# Unix:
cp ./target/release/cmp ~/.local/bin/
```

Restart terminal, then `cmp` works globally.

---

## Commands

```bash
cmp [PATH] [COMMAND] [OPTIONS]
```

| Command | Description |
|---------|-------------|
| `cmp` | Scans your entire codebase and saves the full source code to `context.xml` on disk. This is the default behavior when no command is specified. |
| `cmp map` | Generates a lightweight skeleton showing only imports and function/class signatures (no implementation code). Perfect for giving AI a bird's-eye view of your project structure without burning tokens on function bodies. |
| `cmp source` | Same as default `cmp` - reads all source files and writes them to `context.xml`. Use this when you need the complete code for AI to analyze or modify. |
| `cmp watch` | Starts a background watcher that automatically updates `cmp_map.xml` whenever you save a file. Only generates the skeleton map (not full source) to keep disk usage minimal. Run this in a separate terminal while coding. |
| `cmp copy` | Generates full source code and copies it directly to your clipboard without writing any file to disk. Use this when you want to paste context into an AI chat without leaving files behind. |
| `cmp sync` | Smart incremental update - only re-reads files that changed since the last scan (tracked via `.cmp_memory.json`). Faster than `cmp source` on large projects after the first run. |

---

## Options

| Flag | Description |
|------|-------------|
| `-t, --target <FORMAT>` | Output format: `claude` (default), `cursor`, `raw` |
| `-c, --copy` | Auto-copy to clipboard (skip prompt) |
| `--ignore <FILE>` | Ignore specific files (repeatable) |
| `-h, --help` | Show help |
| `-V, --version` | Show version |

### Examples

```bash
# Target specific folder
cmp src/components
cmp map src
cmp copy lib/utils
cmp watch src

# Auto-copy to clipboard (options go BEFORE command)
cmp -c
cmp -c map
cmp -c src/api

# Ignore specific files
cmp --ignore test.ts
cmp --ignore test.ts --ignore mock.ts
cmp --ignore package.json source

# Different output formats
cmp -t claude          # XML (default)
cmp -t cursor          # Markdown
cmp -t raw             # JSON
cmp -t cursor map      # Skeleton as Markdown

# Combined (options BEFORE command)
cmp -c -t cursor map src/components
cmp --ignore test.ts -c copy src
```

**Note**: Options (`-t`, `-c`, `--ignore`) must come BEFORE the command.

---

## Output Formats

| Target | Format | Output File | Use Case |
|--------|--------|-------------|----------|
| `claude` | XML with `<context>` tags | `.xml` | Anthropic API, Claude caching |
| `cursor` | Markdown with code blocks | `.md` | Cursor chat, .cursorrules |
| `raw` | JSON | `.json` | Programmatic access |

---

## Live Watcher

```bash
cmp watch
cmp watch src    # Watch specific folder
```

- Updates `cmp_map.xml` (skeleton only) on every file change
- 500ms debounce (saves CPU while typing)
- **NO full source written to disk** - only lightweight skeleton
- Respects blacklist (no infinite loops on build artifacts)

### Recommended Workflow

```bash
# Terminal 1: Start watcher (runs in background)
cmp watch

# Terminal 2: When you need full context for AI
cmp copy              # Full source → clipboard (no disk write)
# Paste into AI chat
```

**Result**: Always-current project map, zero extra disk usage.

---

## CMP Report

Every scan shows a summary:

```
CMP REPORT:
============================================
  Included: 12 files (Source Code)
  Ignored Noise: Cargo.lock, package-lock.json (saved ~50k tokens)
============================================
```

If noise files are detected, you'll be prompted:
```
[?] Force-include 2 ignored files? (y/N)
```
Default is No (recommended). Type `y` to include them anyway.

---

## Token Budget

Before copying, CMP checks token count:

| Tokens | Status | Behavior |
|--------|--------|----------|
| < 10,000 | 🟢 Green | Copy immediately |
| 10,000 - 30,000 | 🟡 Yellow | Warning + cost estimate, prompts Y/n |
| > 30,000 | 🔴 Red | Warning, recommends `cmp map` or target folder |

**Token estimation**: Uses `tiktoken` (cl100k_base) for accurate GPT-4/Claude estimates.

**Cost estimate**: ~$0.01 per 1,000 tokens (input pricing).

---

## Output Files

| Command | Output File | Location | Size |
|---------|-------------|----------|------|
| `cmp map` | `cmp_map.xml` | Current directory | KB (skeleton) |
| `cmp watch` | `cmp_map.xml` | Current directory | KB (skeleton) |
| `cmp source` | `context.xml` | Current directory | Full |
| `cmp sync` | `context.xml` | Current directory | Full |
| `cmp copy` | Clipboard only | N/A | 0 disk |

**Memory file**: `.cmp_memory.json` stores file hashes for incremental sync (`cmp sync`).

---

## Skeleton Map Format

The skeleton map (`cmp map`, `cmp watch`) extracts:
- **Imports**: `import`, `use`, `require`, `from ... import`
- **Signatures**: Function/class/struct/interface declarations
- **NO bodies**: Implementation replaced with `// ...`

Example output:
```
use std::path::Path;
use anyhow::Result;

pub fn scan_files(root: &Path) -> Result<Vec<PathBuf>> // ...
pub struct ScanResult // ...
impl ScanResult // ...
```

Supported languages: JavaScript/TypeScript, Rust, Python, Go, Java/Kotlin, C/C++, Ruby, PHP.

---

## Ignored Directories

These directories are never traversed:

```
node_modules, .git, target, dist, vendor, .next, build, out,
__pycache__, .venv, venv, .idea, .vscode, coverage, .nuxt
```

---

## Noise Blacklist (Auto-Ignored)

These files are ignored and reported in CMP Report:

| Category | Files |
|----------|-------|
| Lock Files | `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `bun.lockb`, `Cargo.lock`, `poetry.lock`, `Pipfile.lock`, `Gemfile.lock`, `composer.lock`, `packages.lock.json`, `go.sum` |
| Logs | `*.log` |
| Source Maps | `*.map` |
| Minified | `*.min.js`, `*.min.css` |
| Images | `*.png`, `*.jpg`, `*.jpeg`, `*.ico`, `*.gif`, `*.webp`, `*.bmp` |
| Large SVG | `*.svg` (> 2KB) |

---

## Security Blacklist (Never Included)

These files are silently blocked - never included, never reported:

| Category | Files |
|----------|-------|
| Secrets | `.env`, `.env.local`, `.env.production`, `.env.development`, `secrets.yaml`, `secrets.yml`, `secrets.json` |
| SSH Keys | `id_rsa`, `id_rsa.pub`, `id_ed25519`, `id_ed25519.pub`, `id_dsa` |
| Certificates | `*.pem`, `*.key`, `*.p12`, `*.pfx`, `*.jks`, `*.keystore` |
| Credentials | `credentials`, `credentials.json`, `service-account.json`, `.npmrc`, `.pypirc` |

**Pattern blocking**: Any filename containing `id_rsa`, `id_dsa`, `id_ed25519`, `id_ecdsa`, `aws_access`, `aws_secret`, `credentials`

---

## Custom Ignore List

You can permanently ignore any file by adding it to the ignore lists in `cmp/src/scanner.rs`. This is useful when you have project-specific files that should never be included in context.

### Step 1: Edit scanner.rs

Open `cmp/src/scanner.rs` and find the appropriate list:

```rust
// For files you want IGNORED + REPORTED in CMP Report (user can force-include)
pub const NOISE_LOCK_FILES: &[&str] = &[
    "package-lock.json",
    "yarn.lock",
    // ... add your file here:
    "my-custom-file.txt",
];

// For files you want SILENTLY BLOCKED (never included, never reported)
pub const IGNORED_FILES: &[&str] = &[
    ".DS_Store",
    ".env",
    // ... add your file here:
    "internal-notes.md",
];

// For entire directories to skip
pub const IGNORED_DIRS: &[&str] = &[
    "node_modules",
    ".git",
    // ... add your folder here:
    "my-private-folder",
];
```

### Step 2: Rebuild

```bash
cd cmp
cargo build --release
```

### Step 3: Update your PATH binary

```powershell
# Windows PowerShell
Copy-Item ".\target\release\cmp.exe" "$env:USERPROFILE\.local\bin\cmp.exe" -Force
```

```bash
# Unix/Mac
cp ./target/release/cmp ~/.local/bin/
```

### Which list to use?

| List | Behavior | Use Case |
|------|----------|----------|
| `NOISE_LOCK_FILES` | Ignored + shown in report | Large generated files you might occasionally need |
| `IGNORED_FILES` | Silently blocked forever | Secrets, credentials, internal docs |
| `IGNORED_DIRS` | Entire folder skipped | Build outputs, caches, private folders |

---

## Security

- Runs 100% locally
- No external API calls
- No data sent anywhere
- Secrets automatically blocked
- Binary files auto-skipped (null-byte detection)

---

## Support

- Email: justinlord@empusaai.com
- X: @justin_lords

---

## License

Copyright (c) 2025 EmpusaAI - All rights reserved. See [LICENSE.txt](LICENSE.txt)
