# CMP (Context Memory Protocol)

> **Stop guessing. Start tracing.**

CMP is a high-performance CLI tool written in Rust that solves "AI Context Amnesia." It builds a deterministic dependency graph of your TypeScript/TSX codebase to tell you exactly **what broke** and **what else will break** because of it.

AI tools like Cursor and Claude are great, but they guess. CMP doesn't guess. It uses AST parsing to map your code's DNA with 100% accuracy.

## Why this exists
Developers burn millions of tokens (and dollars) pasting random files into AI context windows hoping the model "figures it out."

CMP flips the script.
1. **Deterministic Context:** instead of feeding AI the whole folder, feed it the exact 3 files that matter.
2. **Impact Analysis:** if you change `auth.ts`, know instantly that `login.tsx` and `profile.tsx` are the only files affected.
3. **No Fluff:** generated specifically for LLM context windows. Zero token waste.

## Installation

### Build from Source
```bash
git clone [https://github.com/justin55afdfdsf5ds45f4ds5f45ds4/cmp-main](https://github.com/justin55afdfdsf5ds45f4ds5f45ds4/cmp-main)
cd cmp
cargo build --release
Add the binary to your PATH and you are ready to go.

Usage
1. The "Fix It" Command (trace)
You have an error in Login.tsx. Don't guess dependencies.

Bash

cmp trace ./src/components/Login.tsx -c
What it does:

Finds exactly what Login.tsx imports (Dependencies).

Finds exactly who imports Login.tsx (Consumers).

Reads the code for these files.

Copies a markdown-formatted crash report to your clipboard.

Paste it into Cursor/Claude: "Here is the context, fix the bug." -> Solved.

2. The "Don't Break Prod" Command (impact)
You are about to change a core utility function. Who relies on it?

Bash

cmp impact ./src/utils/date-formatter.ts
Output:

Plaintext

If `date-formatter.ts` changes, these files may be affected:

Direct Consumers:
 - `components/Header.tsx`
 - `components/Footer.tsx`

Indirect Consumers (Depth 2+):
 - `pages/index.tsx` (via Header)
3. The "God View" (analyze)
Get the full JSON map of your entire project structure.

Bash

cmp analyze ./src
Features
Speed: Written in Rust, parses thousands of files in milliseconds.

Accuracy: Uses swc_ecma_parser for real AST parsing (not regex).

Edge Cases Handled:

Circular Dependencies

Dynamic Imports (await import(...))

Barrel Exports (export * from ...)

Type-only imports

Privacy: Local only. No code leaves your machine until you paste it.

Tech Stack
Language: Rust

Parser: SWC (Speedy Web Compiler)

Graph: Petgraph

CLI: Clap

License
copyright
