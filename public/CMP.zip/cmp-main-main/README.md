# CMP (Context Memory Protocol) - Beta v0.3

CMP is a local "State Injection" layer designed to solve Context Amnesia in long LLM sessions.

## The Problem

LLMs treat every session as a fresh start. "Project Prompts" are static and expensive.

CMP creates a dynamic **State Key** that captures architectural decisions, negative constraints, and active variables from your previous session.

## Components

### mu (Memory Unit) - Rust CLI

A blazing-fast codebase mapper that generates deterministic context snapshots for AI context windows.

```bash
# Build
cd mu && cargo build --release

# Generate context (Claude XML format)
mu

# Different output formats
mu --target claude    # XML optimized for Claude/Anthropic caching
mu --target cursor    # Markdown for Cursor chat/rules
mu --target raw       # JSON dump

# Incremental sync (only changed files)
mu sync

# Watch mode (auto-regenerates on changes)
mu watch

# Copy to clipboard automatically
mu --copy
mu watch --copy       # Auto-copy on every change
```

## Features

### Output Formats (`--target`)

| Target | Format | Best For |
|--------|--------|----------|
| `claude` | XML with `<context>` tags | Anthropic API, Claude caching |
| `cursor` | Markdown with code blocks | Cursor chat, .cursorrules |
| `raw` | JSON | Programmatic access |

### Living Memory (`sync`)

Incremental updates that only re-parse changed files:
- Uses file modification timestamps to detect dirty files
- Patches existing `.mu_memory.json` state
- Avoids full re-scan overhead on large projects

### Token Estimation

Every output shows estimated token count:
```
✓ Generated context (42 files, ~12.5k tokens)
```

Uses `tiktoken` (cl100k_base) for accurate GPT-4/Claude estimates.

### Clipboard Integration (`--copy`)

Zero-friction workflow:
```bash
mu watch --copy
# Change code → auto-sync → auto-copy → Cmd+V into chat
```

## Ignored Directories

Hard-coded at iterator level (never traversed):

- `node_modules`, `.git`, `target`, `dist`, `vendor`, `.next`
- `build`, `__pycache__`, `.venv`, `venv`, `.idea`, `.vscode`, `coverage`, `.nuxt`

## Security (Paranoid Mode)

Hard-blocked files that are **never** included:

| Category | Files |
|----------|-------|
| Secrets | `.env`, `.env.local`, `.env.production`, `secrets.yaml`, `secrets.json` |
| SSH Keys | `id_rsa`, `id_ed25519`, `id_dsa`, `*.pem`, `*.key` |
| Credentials | `credentials.json`, `service-account.json`, `.npmrc`, `.pypirc` |
| Certificates | `*.p12`, `*.pfx`, `*.jks`, `*.keystore` |

Pattern blocking: anything containing `id_rsa`, `aws_access`, `aws_secret`, `credentials`

### Additional Security

- Runs 100% locally
- No LLM calls required for mu
- No data sent to external servers

## Quick Start

```bash
# Build mu
cd mu && cargo build --release

# Full codebase map with token count
./target/release/mu

# Watch + auto-clipboard workflow
./target/release/mu watch --copy
```

## Support

- Email: justinlord@empusaai.com
- X: @justin_lords
