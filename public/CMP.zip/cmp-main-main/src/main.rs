use clap::{Parser, Subcommand};
use petgraph::graph::{DiGraph, NodeIndex};
use petgraph::Direction;
use serde::Serialize;
use std::collections::{HashMap, HashSet, VecDeque};
use std::fs;
use std::path::{Path, PathBuf};
use swc_common::sync::Lrc;
use swc_common::{FileName, SourceMap};
use swc_ecma_ast::{CallExpr, Callee, EsVersion, Expr, Lit, ModuleDecl, ModuleItem};
use swc_ecma_parser::{lexer::Lexer, StringInput, Syntax, TsConfig};
use walkdir::WalkDir;

#[derive(Parser)]
#[command(name = "cmp")]
#[command(about = "Context Memory Protocol - TypeScript dependency graph analyzer")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Analyze a TypeScript/TSX project and output dependency graph
    Analyze {
        /// Path to the source directory
        #[arg(default_value = "./src")]
        path: PathBuf,
    },
    /// Show reverse impact analysis - which files are affected if this file changes
    Impact {
        /// Path to the file to analyze
        file: PathBuf,
        /// Path to the source directory
        #[arg(short, long, default_value = "./src")]
        root: PathBuf,
        /// Copy output to clipboard instead of printing
        #[arg(short, long)]
        copy: bool,
    },
    /// Generate AI-ready context dump for debugging errors
    Trace {
        /// Path to the file with the error
        file: PathBuf,
        /// Path to the source directory
        #[arg(short, long, default_value = "./src")]
        root: PathBuf,
        /// Copy output to clipboard instead of printing
        #[arg(short, long)]
        copy: bool,
    },
}

#[derive(Debug, Serialize)]
struct DependencyGraph {
    dependencies: HashMap<String, Vec<String>>,
}

/// Recursively find all .ts and .tsx files, ignoring node_modules
fn find_typescript_files(root: &Path) -> Vec<PathBuf> {
    let mut files = Vec::new();

    for entry in WalkDir::new(root)
        .into_iter()
        .filter_entry(|e| {
            // Always allow the root directory
            if e.depth() == 0 {
                return true;
            }
            let name = e.file_name().to_string_lossy();
            // Skip hidden directories and node_modules
            !name.starts_with('.') && name != "node_modules"
        })
        .filter_map(|e| e.ok())
    {
        let path = entry.path();
        if path.is_file() {
            if let Some(ext) = path.extension() {
                let ext_str = ext.to_string_lossy().to_lowercase();
                if ext_str == "ts" || ext_str == "tsx" {
                    files.push(path.to_path_buf());
                }
            }
        }
    }

    files
}

/// Extract import paths from a TypeScript/TSX file using SWC parser
fn extract_imports(file_path: &Path) -> Vec<String> {
    let source_code = match fs::read_to_string(file_path) {
        Ok(content) => content,
        Err(_) => return Vec::new(),
    };

    let cm: Lrc<SourceMap> = Default::default();
    let fm = cm.new_source_file(
        FileName::Real(file_path.to_path_buf()),
        source_code,
    );

    let is_tsx = file_path
        .extension()
        .map(|e| e.to_string_lossy().to_lowercase() == "tsx")
        .unwrap_or(false);

    let syntax = Syntax::Typescript(TsConfig {
        tsx: is_tsx,
        decorators: true,
        ..Default::default()
    });

    let lexer = Lexer::new(
        syntax,
        EsVersion::latest(),
        StringInput::from(&*fm),
        None,
    );

    let mut parser = swc_ecma_parser::Parser::new_from(lexer);

    let module = match parser.parse_module() {
        Ok(m) => m,
        Err(_) => return Vec::new(),
    };

    let mut imports = Vec::new();

    for item in &module.body {
        match item {
            // Static imports: import x from 'path'
            ModuleItem::ModuleDecl(ModuleDecl::Import(import_decl)) => {
                imports.push(import_decl.src.value.to_string());
            }
            // Export from: export { x } from 'path'
            ModuleItem::ModuleDecl(ModuleDecl::ExportNamed(export_named)) => {
                if let Some(src) = &export_named.src {
                    imports.push(src.value.to_string());
                }
            }
            // Export all: export * from 'path'
            ModuleItem::ModuleDecl(ModuleDecl::ExportAll(export_all)) => {
                imports.push(export_all.src.value.to_string());
            }
            // Export default declarations may contain dynamic imports
            ModuleItem::ModuleDecl(ModuleDecl::ExportDefaultDecl(export_default)) => {
                if let swc_ecma_ast::DefaultDecl::Fn(fn_expr) = &export_default.decl {
                    if let Some(body) = &fn_expr.function.body {
                        for stmt in &body.stmts {
                            extract_dynamic_imports_from_stmt(stmt, &mut imports);
                        }
                    }
                }
            }
            // Export declarations (export const x = ...) may contain dynamic imports
            ModuleItem::ModuleDecl(ModuleDecl::ExportDecl(export_decl)) => {
                extract_dynamic_imports_from_decl(&export_decl.decl, &mut imports);
            }
            // Dynamic imports: import('path')
            ModuleItem::Stmt(stmt) => {
                extract_dynamic_imports_from_stmt(stmt, &mut imports);
            }
            _ => {}
        }
    }

    imports
}

/// Recursively extract dynamic import() calls from statements
fn extract_dynamic_imports_from_stmt(stmt: &swc_ecma_ast::Stmt, imports: &mut Vec<String>) {
    use swc_ecma_ast::Stmt;

    match stmt {
        Stmt::Expr(expr_stmt) => {
            extract_dynamic_imports_from_expr(&expr_stmt.expr, imports);
        }
        Stmt::Block(block) => {
            for s in &block.stmts {
                extract_dynamic_imports_from_stmt(s, imports);
            }
        }
        Stmt::If(if_stmt) => {
            extract_dynamic_imports_from_stmt(&if_stmt.cons, imports);
            if let Some(alt) = &if_stmt.alt {
                extract_dynamic_imports_from_stmt(alt, imports);
            }
        }
        Stmt::Return(ret) => {
            if let Some(arg) = &ret.arg {
                extract_dynamic_imports_from_expr(arg, imports);
            }
        }
        Stmt::Decl(decl) => {
            extract_dynamic_imports_from_decl(decl, imports);
        }
        Stmt::For(for_stmt) => {
            extract_dynamic_imports_from_stmt(&for_stmt.body, imports);
        }
        Stmt::ForIn(for_in) => {
            extract_dynamic_imports_from_stmt(&for_in.body, imports);
        }
        Stmt::ForOf(for_of) => {
            extract_dynamic_imports_from_stmt(&for_of.body, imports);
        }
        Stmt::While(while_stmt) => {
            extract_dynamic_imports_from_stmt(&while_stmt.body, imports);
        }
        Stmt::Try(try_stmt) => {
            for s in &try_stmt.block.stmts {
                extract_dynamic_imports_from_stmt(s, imports);
            }
            if let Some(handler) = &try_stmt.handler {
                for s in &handler.body.stmts {
                    extract_dynamic_imports_from_stmt(s, imports);
                }
            }
            if let Some(finalizer) = &try_stmt.finalizer {
                for s in &finalizer.stmts {
                    extract_dynamic_imports_from_stmt(s, imports);
                }
            }
        }
        _ => {}
    }
}

/// Extract dynamic imports from declarations
fn extract_dynamic_imports_from_decl(decl: &swc_ecma_ast::Decl, imports: &mut Vec<String>) {
    use swc_ecma_ast::Decl;

    match decl {
        Decl::Var(var_decl) => {
            for decl in &var_decl.decls {
                if let Some(init) = &decl.init {
                    extract_dynamic_imports_from_expr(init, imports);
                }
            }
        }
        Decl::Fn(fn_decl) => {
            if let Some(body) = &fn_decl.function.body {
                for stmt in &body.stmts {
                    extract_dynamic_imports_from_stmt(stmt, imports);
                }
            }
        }
        Decl::Class(class_decl) => {
            for member in &class_decl.class.body {
                if let swc_ecma_ast::ClassMember::Method(method) = member {
                    if let Some(body) = &method.function.body {
                        for stmt in &body.stmts {
                            extract_dynamic_imports_from_stmt(stmt, imports);
                        }
                    }
                }
            }
        }
        _ => {}
    }
}

/// Extract dynamic import paths from expressions
fn extract_dynamic_imports_from_expr(expr: &Expr, imports: &mut Vec<String>) {
    match expr {
        Expr::Call(CallExpr {
            callee: Callee::Import(_),
            args,
            ..
        }) => {
            if let Some(arg) = args.first() {
                if let Expr::Lit(Lit::Str(s)) = &*arg.expr {
                    imports.push(s.value.to_string());
                }
            }
        }
        Expr::Call(call_expr) => {
            for arg in &call_expr.args {
                extract_dynamic_imports_from_expr(&arg.expr, imports);
            }
        }
        Expr::Arrow(arrow) => {
            match &*arrow.body {
                swc_ecma_ast::BlockStmtOrExpr::Expr(e) => {
                    extract_dynamic_imports_from_expr(e, imports);
                }
                swc_ecma_ast::BlockStmtOrExpr::BlockStmt(block) => {
                    for stmt in &block.stmts {
                        extract_dynamic_imports_from_stmt(stmt, imports);
                    }
                }
            }
        }
        Expr::Await(await_expr) => {
            extract_dynamic_imports_from_expr(&await_expr.arg, imports);
        }
        Expr::Paren(paren) => {
            extract_dynamic_imports_from_expr(&paren.expr, imports);
        }
        Expr::Fn(fn_expr) => {
            if let Some(body) = &fn_expr.function.body {
                for stmt in &body.stmts {
                    extract_dynamic_imports_from_stmt(stmt, imports);
                }
            }
        }
        _ => {}
    }
}


/// Resolve a relative import path to an absolute file path
fn resolve_import_path(from_file: &Path, import_path: &str, all_files: &[PathBuf]) -> Option<PathBuf> {
    // Skip external packages (not starting with . or /)
    if !import_path.starts_with('.') && !import_path.starts_with('/') {
        return None;
    }

    let from_dir = from_file.parent()?;
    let mut resolved = from_dir.join(import_path);

    // Normalize the path (handle .. and .)
    resolved = normalize_path(&resolved);

    // Try exact match first
    if resolved.exists() && resolved.is_file() {
        return Some(resolved);
    }

    // Try adding extensions: .ts, .tsx, /index.ts, /index.tsx
    let extensions = [".ts", ".tsx", "/index.ts", "/index.tsx"];
    
    for ext in &extensions {
        let with_ext = PathBuf::from(format!("{}{}", resolved.display(), ext));
        let normalized = normalize_path(&with_ext);
        
        // Check if this file exists in our known files
        for known_file in all_files {
            let known_normalized = normalize_path(known_file);
            if paths_equal(&normalized, &known_normalized) {
                return Some(known_file.clone());
            }
        }
        
        // Also check filesystem directly
        if normalized.exists() && normalized.is_file() {
            return Some(normalized);
        }
    }

    None
}

/// Normalize a path by resolving . and .. components
fn normalize_path(path: &Path) -> PathBuf {
    let mut components = Vec::new();
    
    for component in path.components() {
        match component {
            std::path::Component::ParentDir => {
                components.pop();
            }
            std::path::Component::CurDir => {}
            c => components.push(c),
        }
    }
    
    components.iter().collect()
}

/// Compare two paths for equality (handles different path separators)
fn paths_equal(a: &Path, b: &Path) -> bool {
    let a_str = a.to_string_lossy().replace('\\', "/");
    let b_str = b.to_string_lossy().replace('\\', "/");
    a_str == b_str
}

/// Build the dependency graph from a list of TypeScript files
fn build_dependency_graph(_root: &Path, files: &[PathBuf]) -> DiGraph<PathBuf, ()> {
    let mut graph: DiGraph<PathBuf, ()> = DiGraph::new();
    let mut node_indices: HashMap<PathBuf, NodeIndex> = HashMap::new();

    // First pass: add all files as nodes
    for file in files {
        let normalized = normalize_path(file);
        let idx = graph.add_node(normalized.clone());
        node_indices.insert(normalized, idx);
    }

    // Second pass: add edges for imports
    for file in files {
        let normalized_file = normalize_path(file);
        let imports = extract_imports(file);

        for import_path in imports {
            if let Some(resolved) = resolve_import_path(file, &import_path, files) {
                let normalized_resolved = normalize_path(&resolved);
                
                if let (Some(&from_idx), Some(&to_idx)) = (
                    node_indices.get(&normalized_file),
                    node_indices.get(&normalized_resolved),
                ) {
                    // Add edge: from_file imports to_file
                    graph.add_edge(from_idx, to_idx, ());
                }
            }
        }
    }

    graph
}

/// Convert the graph to a JSON-serializable structure
fn graph_to_dependency_map(graph: &DiGraph<PathBuf, ()>, root: &Path) -> DependencyGraph {
    let mut dependencies: HashMap<String, Vec<String>> = HashMap::new();

    for node_idx in graph.node_indices() {
        let file_path = &graph[node_idx];
        let relative_path = file_path
            .strip_prefix(root)
            .unwrap_or(file_path)
            .to_string_lossy()
            .replace('\\', "/");

        let mut deps: Vec<String> = graph
            .neighbors(node_idx)
            .map(|neighbor_idx| {
                let neighbor_path = &graph[neighbor_idx];
                neighbor_path
                    .strip_prefix(root)
                    .unwrap_or(neighbor_path)
                    .to_string_lossy()
                    .replace('\\', "/")
            })
            .collect();

        // Sort for deterministic output
        deps.sort();
        dependencies.insert(relative_path, deps);
    }

    DependencyGraph { dependencies }
}

/// Find a node in the graph by file path (supports both relative and absolute)
fn find_node_by_path(
    graph: &DiGraph<PathBuf, ()>,
    target: &Path,
    root: &Path,
) -> Option<NodeIndex> {
    let target_normalized = normalize_path(target);
    let target_relative = target.strip_prefix(root).unwrap_or(target);
    
    for idx in graph.node_indices() {
        let node_path = &graph[idx];
        let node_normalized = normalize_path(node_path);
        let node_relative = node_path.strip_prefix(root).unwrap_or(node_path);
        
        if paths_equal(&target_normalized, &node_normalized)
            || paths_equal(target_relative, node_relative)
            || node_path.ends_with(target)
            || target.ends_with(node_relative)
        {
            return Some(idx);
        }
    }
    None
}

/// Get all files that directly or indirectly import the target file (reverse dependencies)
fn get_impact_chain(
    graph: &DiGraph<PathBuf, ()>,
    target_idx: NodeIndex,
    root: &Path,
) -> (Vec<String>, Vec<String>) {
    let mut direct: Vec<String> = Vec::new();
    let mut indirect: Vec<String> = Vec::new();
    let mut visited: HashSet<NodeIndex> = HashSet::new();
    let mut queue: VecDeque<(NodeIndex, usize)> = VecDeque::new();
    
    visited.insert(target_idx);
    
    // Find direct consumers (files that import target)
    for neighbor in graph.neighbors_directed(target_idx, Direction::Incoming) {
        if visited.insert(neighbor) {
            let path = &graph[neighbor];
            let relative = path
                .strip_prefix(root)
                .unwrap_or(path)
                .to_string_lossy()
                .replace('\\', "/");
            direct.push(relative);
            queue.push_back((neighbor, 1));
        }
    }
    
    // BFS for indirect consumers
    while let Some((current, depth)) = queue.pop_front() {
        for neighbor in graph.neighbors_directed(current, Direction::Incoming) {
            if visited.insert(neighbor) {
                let path = &graph[neighbor];
                let relative = path
                    .strip_prefix(root)
                    .unwrap_or(path)
                    .to_string_lossy()
                    .replace('\\', "/");
                indirect.push(relative);
                queue.push_back((neighbor, depth + 1));
            }
        }
    }
    
    direct.sort();
    indirect.sort();
    (direct, indirect)
}

/// Get direct dependencies (files that target imports)
fn get_dependencies(
    graph: &DiGraph<PathBuf, ()>,
    target_idx: NodeIndex,
    root: &Path,
) -> Vec<String> {
    let mut deps: Vec<String> = graph
        .neighbors_directed(target_idx, Direction::Outgoing)
        .map(|idx| {
            let path = &graph[idx];
            path.strip_prefix(root)
                .unwrap_or(path)
                .to_string_lossy()
                .replace('\\', "/")
        })
        .collect();
    deps.sort();
    deps
}

/// Get direct consumers (files that import target)
fn get_consumers(
    graph: &DiGraph<PathBuf, ()>,
    target_idx: NodeIndex,
    root: &Path,
) -> Vec<String> {
    let mut consumers: Vec<String> = graph
        .neighbors_directed(target_idx, Direction::Incoming)
        .map(|idx| {
            let path = &graph[idx];
            path.strip_prefix(root)
                .unwrap_or(path)
                .to_string_lossy()
                .replace('\\', "/")
        })
        .collect();
    consumers.sort();
    consumers
}

/// Generate the AI-ready context report
fn generate_context_report(
    graph: &DiGraph<PathBuf, ()>,
    target_idx: NodeIndex,
    root: &Path,
) -> String {
    let target_path = &graph[target_idx];
    let target_relative = target_path
        .strip_prefix(root)
        .unwrap_or(target_path)
        .to_string_lossy()
        .replace('\\', "/");
    
    let dependencies = get_dependencies(graph, target_idx, root);
    let consumers = get_consumers(graph, target_idx, root);
    
    let mut report = String::new();
    
    // Header
    report.push_str("## CMP Context Report\n\n");
    report.push_str(&format!("**Target:** `{}`\n\n", target_relative));
    
    // Dependencies section
    if !dependencies.is_empty() {
        report.push_str("**Dependencies (files this imports):**\n");
        for dep in &dependencies {
            report.push_str(&format!("- `{}`\n", dep));
        }
        report.push('\n');
    } else {
        report.push_str("**Dependencies:** None\n\n");
    }
    
    // Consumers section
    if !consumers.is_empty() {
        report.push_str("**Consumers (files that import this):**\n");
        for consumer in &consumers {
            report.push_str(&format!("- `{}`\n", consumer));
        }
        report.push('\n');
    } else {
        report.push_str("**Consumers:** None\n\n");
    }
    
    // Code context section
    report.push_str("---\n\n");
    report.push_str("## Code Context\n\n");
    
    // Target file code
    report.push_str(&format!("### `{}`\n\n", target_relative));
    report.push_str("```typescript\n");
    if let Ok(content) = fs::read_to_string(target_path) {
        report.push_str(&content);
        if !content.ends_with('\n') {
            report.push('\n');
        }
    } else {
        report.push_str("// Error: Could not read file\n");
    }
    report.push_str("```\n\n");
    
    // Dependency files code (depth 1 only)
    for dep in &dependencies {
        let dep_path = root.join(dep);
        report.push_str(&format!("### `{}`\n\n", dep));
        report.push_str("```typescript\n");
        if let Ok(content) = fs::read_to_string(&dep_path) {
            report.push_str(&content);
            if !content.ends_with('\n') {
                report.push('\n');
            }
        } else {
            report.push_str("// Error: Could not read file\n");
        }
        report.push_str("```\n\n");
    }
    
    report
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Analyze { path } => {
            let root = resolve_path(&path);
            
            if !root.exists() {
                eprintln!("Error: Path '{}' does not exist", root.display());
                std::process::exit(1);
            }

            let files = find_typescript_files(&root);

            if files.is_empty() {
                eprintln!("No TypeScript files found in '{}'", root.display());
                std::process::exit(0);
            }

            let graph = build_dependency_graph(&root, &files);
            let dependency_map = graph_to_dependency_map(&graph, &root);

            let json = serde_json::to_string_pretty(&dependency_map)
                .expect("Failed to serialize dependency graph");

            println!("{}", json);
        }
        
        Commands::Impact { file, root, copy } => {
            let root = resolve_path(&root);
            let file = resolve_path(&file);
            
            if !root.exists() {
                eprintln!("Error: Root path '{}' does not exist", root.display());
                std::process::exit(1);
            }

            let files = find_typescript_files(&root);
            if files.is_empty() {
                eprintln!("No TypeScript files found in '{}'", root.display());
                std::process::exit(1);
            }

            let graph = build_dependency_graph(&root, &files);
            
            let target_idx = match find_node_by_path(&graph, &file, &root) {
                Some(idx) => idx,
                None => {
                    eprintln!("Error: File '{}' not found in dependency graph", file.display());
                    std::process::exit(1);
                }
            };
            
            let target_relative = graph[target_idx]
                .strip_prefix(&root)
                .unwrap_or(&graph[target_idx])
                .to_string_lossy()
                .replace('\\', "/");
            
            let (direct, indirect) = get_impact_chain(&graph, target_idx, &root);
            
            let mut output = String::new();
            output.push_str("## Impact Analysis\n\n");
            output.push_str(&format!("**If `{}` changes, these files may be affected:**\n\n", target_relative));
            
            if direct.is_empty() && indirect.is_empty() {
                output.push_str("No files depend on this file.\n");
            } else {
                if !direct.is_empty() {
                    output.push_str(&format!("**Direct Consumers ({}):**\n", direct.len()));
                    for f in &direct {
                        output.push_str(&format!("  - `{}`\n", f));
                    }
                    output.push('\n');
                }
                
                if !indirect.is_empty() {
                    output.push_str(&format!("**Indirect Consumers ({}):**\n", indirect.len()));
                    for f in &indirect {
                        output.push_str(&format!("  - `{}`\n", f));
                    }
                    output.push('\n');
                }
                
                output.push_str(&format!("**Total Impact:** {} file(s)\n", direct.len() + indirect.len()));
            }
            
            output_or_copy(&output, copy);
        }
        
        Commands::Trace { file, root, copy } => {
            let root = resolve_path(&root);
            let file = resolve_path(&file);
            
            if !root.exists() {
                eprintln!("Error: Root path '{}' does not exist", root.display());
                std::process::exit(1);
            }

            let files = find_typescript_files(&root);
            if files.is_empty() {
                eprintln!("No TypeScript files found in '{}'", root.display());
                std::process::exit(1);
            }

            let graph = build_dependency_graph(&root, &files);
            
            let target_idx = match find_node_by_path(&graph, &file, &root) {
                Some(idx) => idx,
                None => {
                    eprintln!("Error: File '{}' not found in dependency graph", file.display());
                    std::process::exit(1);
                }
            };
            
            let report = generate_context_report(&graph, target_idx, &root);
            output_or_copy(&report, copy);
        }
    }
}

/// Output to stdout or copy to clipboard based on flag
fn output_or_copy(content: &str, copy: bool) {
    if copy {
        match arboard::Clipboard::new() {
            Ok(mut clipboard) => {
                match clipboard.set_text(content.to_string()) {
                    Ok(_) => println!("✓ Copied to clipboard!"),
                    Err(e) => {
                        eprintln!("Error: Failed to copy to clipboard: {}", e);
                        std::process::exit(1);
                    }
                }
            }
            Err(e) => {
                eprintln!("Error: Failed to access clipboard: {}", e);
                std::process::exit(1);
            }
        }
    } else {
        println!("{}", content);
    }
}

/// Resolve a path to absolute
fn resolve_path(path: &Path) -> PathBuf {
    if path.is_absolute() {
        path.to_path_buf()
    } else {
        std::env::current_dir()
            .expect("Failed to get current directory")
            .join(path)
    }
}


#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::{self, File};
    use std::io::Write;
    use tempfile::TempDir;

    /// Helper to write a file and ensure it's flushed
    fn write_file(path: &Path, content: &str) {
        let mut file = File::create(path).expect("Failed to create file");
        file.write_all(content.as_bytes()).expect("Failed to write file");
        file.sync_all().expect("Failed to sync file");
    }

    /// Creates a temporary TypeScript project structure for testing
    fn create_test_project() -> TempDir {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create child.ts
        let child_content = r#"export const greet = (name: string): string => {
    return `Hello, ${name}!`;
};"#;
        write_file(&root.join("child.ts"), child_content);

        // Create root.ts that imports child.ts
        let root_content = r#"import { greet } from './child';

console.log(greet('World'));"#;
        write_file(&root.join("root.ts"), root_content);

        temp_dir
    }

    #[test]
    fn test_find_typescript_files() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);

        assert_eq!(files.len(), 2, "Verification Failed: Expected 2 TypeScript files");
        
        let file_names: Vec<String> = files
            .iter()
            .map(|p| p.file_name().unwrap().to_string_lossy().to_string())
            .collect();
        
        assert!(file_names.contains(&"root.ts".to_string()), "Verification Failed: root.ts not found");
        assert!(file_names.contains(&"child.ts".to_string()), "Verification Failed: child.ts not found");
    }

    #[test]
    fn test_extract_imports() {
        let temp_dir = create_test_project();
        let root_ts = temp_dir.path().join("root.ts");
        
        let imports = extract_imports(&root_ts);
        
        assert_eq!(imports.len(), 1, "Verification Failed: Expected 1 import");
        assert_eq!(imports[0], "./child", "Verification Failed: Expected import './child'");
    }

    #[test]
    fn test_dependency_graph_edge_exists() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        
        let graph = build_dependency_graph(root, &files);
        
        // Find node indices for root.ts and child.ts
        let mut root_idx: Option<NodeIndex> = None;
        let mut child_idx: Option<NodeIndex> = None;
        
        for idx in graph.node_indices() {
            let path = &graph[idx];
            let file_name = path.file_name().unwrap().to_string_lossy();
            if file_name == "root.ts" {
                root_idx = Some(idx);
            } else if file_name == "child.ts" {
                child_idx = Some(idx);
            }
        }
        
        let root_idx = root_idx.expect("Verification Failed: root.ts node not found in graph");
        let child_idx = child_idx.expect("Verification Failed: child.ts node not found in graph");
        
        // Verify edge exists from root.ts to child.ts
        let has_edge = graph.contains_edge(root_idx, child_idx);
        
        if !has_edge {
            panic!("Verification Failed: No directed edge from root.ts to child.ts");
        }
    }

    #[test]
    fn test_dependency_map_output() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        
        let graph = build_dependency_graph(root, &files);
        let dep_map = graph_to_dependency_map(&graph, root);
        
        // Verify root.ts has child.ts as dependency
        let root_deps = dep_map.dependencies.get("root.ts")
            .expect("Verification Failed: root.ts not in dependency map");
        
        assert!(
            root_deps.contains(&"child.ts".to_string()),
            "Verification Failed: child.ts not listed as dependency of root.ts"
        );
        
        // Verify child.ts has no dependencies
        let child_deps = dep_map.dependencies.get("child.ts")
            .expect("Verification Failed: child.ts not in dependency map");
        
        assert!(
            child_deps.is_empty(),
            "Verification Failed: child.ts should have no dependencies"
        );
    }

    #[test]
    fn test_tsx_file_parsing() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create a TSX component
        let component_content = r#"import React from 'react';
import { helper } from './utils';

export const Component: React.FC = () => {
    return <div>{helper()}</div>;
};"#;
        write_file(&root.join("Component.tsx"), component_content);

        // Create utils.ts
        write_file(&root.join("utils.ts"), "export const helper = () => 'Hello';");

        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        // Find Component.tsx node
        let mut component_idx: Option<NodeIndex> = None;
        let mut utils_idx: Option<NodeIndex> = None;
        
        for idx in graph.node_indices() {
            let path = &graph[idx];
            let file_name = path.file_name().unwrap().to_string_lossy();
            if file_name == "Component.tsx" {
                component_idx = Some(idx);
            } else if file_name == "utils.ts" {
                utils_idx = Some(idx);
            }
        }
        
        let component_idx = component_idx.expect("Verification Failed: Component.tsx not found");
        let utils_idx = utils_idx.expect("Verification Failed: utils.ts not found");
        
        assert!(
            graph.contains_edge(component_idx, utils_idx),
            "Verification Failed: No edge from Component.tsx to utils.ts"
        );
    }

    #[test]
    fn test_nested_directory_imports() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create nested structure
        let components_dir = root.join("components");
        fs::create_dir(&components_dir).expect("Failed to create components dir");

        // Create components/Button.tsx
        let button_content = r#"import { theme } from '../styles';
export const Button = () => <button style={{color: theme.primary}}>Click</button>;"#;
        write_file(&components_dir.join("Button.tsx"), button_content);

        // Create styles.ts at root
        write_file(&root.join("styles.ts"), "export const theme = { primary: 'blue' };");

        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        let mut button_idx: Option<NodeIndex> = None;
        let mut styles_idx: Option<NodeIndex> = None;
        
        for idx in graph.node_indices() {
            let path = &graph[idx];
            let file_name = path.file_name().unwrap().to_string_lossy();
            if file_name == "Button.tsx" {
                button_idx = Some(idx);
            } else if file_name == "styles.ts" {
                styles_idx = Some(idx);
            }
        }
        
        let button_idx = button_idx.expect("Verification Failed: Button.tsx not found");
        let styles_idx = styles_idx.expect("Verification Failed: styles.ts not found");
        
        assert!(
            graph.contains_edge(button_idx, styles_idx),
            "Verification Failed: No edge from Button.tsx to styles.ts (nested import failed)"
        );
    }

    #[test]
    fn test_dynamic_import() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create lazy.ts with dynamic import
        let lazy_content = r#"const loadModule = async () => {
    const mod = await import('./heavy');
    return mod;
};"#;
        write_file(&root.join("lazy.ts"), lazy_content);

        // Create heavy.ts
        write_file(&root.join("heavy.ts"), "export const heavyComputation = () => 42;");

        let imports = extract_imports(&root.join("lazy.ts"));
        
        assert!(
            imports.contains(&"./heavy".to_string()),
            "Verification Failed: Dynamic import './heavy' not extracted"
        );
    }

    #[test]
    fn test_export_from_syntax() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create index.ts with re-exports
        let index_content = r#"export { foo } from './foo';
export * from './bar';"#;
        write_file(&root.join("index.ts"), index_content);

        // Create foo.ts
        write_file(&root.join("foo.ts"), "export const foo = 'foo';");

        // Create bar.ts
        write_file(&root.join("bar.ts"), "export const bar = 'bar';");

        let imports = extract_imports(&root.join("index.ts"));
        
        assert!(
            imports.contains(&"./foo".to_string()),
            "Verification Failed: export from './foo' not extracted"
        );
        assert!(
            imports.contains(&"./bar".to_string()),
            "Verification Failed: export * from './bar' not extracted"
        );
    }

    #[test]
    fn test_ignores_node_modules() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create node_modules directory with a .ts file
        let node_modules = root.join("node_modules");
        fs::create_dir(&node_modules).expect("Failed to create node_modules");
        
        let pkg_dir = node_modules.join("some-package");
        fs::create_dir(&pkg_dir).expect("Failed to create package dir");
        
        write_file(&pkg_dir.join("index.ts"), "export const x = 1;");

        // Create a regular source file
        write_file(&root.join("app.ts"), "console.log('app');");

        let files = find_typescript_files(root);
        
        assert_eq!(files.len(), 1, "Verification Failed: Should only find 1 file (node_modules should be ignored)");
        assert!(
            files[0].file_name().unwrap().to_string_lossy() == "app.ts",
            "Verification Failed: Only app.ts should be found"
        );
    }

    #[test]
    fn test_json_output_format() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        
        let graph = build_dependency_graph(root, &files);
        let dep_map = graph_to_dependency_map(&graph, root);
        
        let json = serde_json::to_string_pretty(&dep_map)
            .expect("Verification Failed: Failed to serialize to JSON");
        
        // Verify it's valid JSON by parsing it back
        let parsed: serde_json::Value = serde_json::from_str(&json)
            .expect("Verification Failed: Output is not valid JSON");
        
        assert!(
            parsed.get("dependencies").is_some(),
            "Verification Failed: JSON output missing 'dependencies' key"
        );
    }

    #[test]
    fn test_impact_analysis_direct() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        // Find child.ts node - root.ts imports it, so root.ts should be in impact
        let child_idx = find_node_by_path(&graph, &root.join("child.ts"), root)
            .expect("Verification Failed: child.ts not found");
        
        let (direct, indirect) = get_impact_chain(&graph, child_idx, root);
        
        assert!(
            direct.contains(&"root.ts".to_string()),
            "Verification Failed: root.ts should be a direct consumer of child.ts"
        );
        assert!(
            indirect.is_empty(),
            "Verification Failed: child.ts should have no indirect consumers in this test"
        );
    }

    #[test]
    fn test_impact_analysis_indirect() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create a chain: a.ts -> b.ts -> c.ts
        write_file(&root.join("c.ts"), "export const c = 'c';");
        write_file(&root.join("b.ts"), "import { c } from './c';\nexport const b = c;");
        write_file(&root.join("a.ts"), "import { b } from './b';\nconsole.log(b);");

        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        let c_idx = find_node_by_path(&graph, &root.join("c.ts"), root)
            .expect("Verification Failed: c.ts not found");
        
        let (direct, indirect) = get_impact_chain(&graph, c_idx, root);
        
        assert!(
            direct.contains(&"b.ts".to_string()),
            "Verification Failed: b.ts should be a direct consumer of c.ts"
        );
        assert!(
            indirect.contains(&"a.ts".to_string()),
            "Verification Failed: a.ts should be an indirect consumer of c.ts"
        );
    }

    #[test]
    fn test_get_dependencies() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        let root_idx = find_node_by_path(&graph, &root.join("root.ts"), root)
            .expect("Verification Failed: root.ts not found");
        
        let deps = get_dependencies(&graph, root_idx, root);
        
        assert!(
            deps.contains(&"child.ts".to_string()),
            "Verification Failed: child.ts should be a dependency of root.ts"
        );
    }

    #[test]
    fn test_get_consumers() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        let child_idx = find_node_by_path(&graph, &root.join("child.ts"), root)
            .expect("Verification Failed: child.ts not found");
        
        let consumers = get_consumers(&graph, child_idx, root);
        
        assert!(
            consumers.contains(&"root.ts".to_string()),
            "Verification Failed: root.ts should be a consumer of child.ts"
        );
    }

    #[test]
    fn test_context_report_generation() {
        let temp_dir = create_test_project();
        let root = temp_dir.path();
        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        
        let root_idx = find_node_by_path(&graph, &root.join("root.ts"), root)
            .expect("Verification Failed: root.ts not found");
        
        let report = generate_context_report(&graph, root_idx, root);
        
        // Verify report structure
        assert!(
            report.contains("## CMP Context Report"),
            "Verification Failed: Report missing header"
        );
        assert!(
            report.contains("**Target:** `root.ts`"),
            "Verification Failed: Report missing target"
        );
        assert!(
            report.contains("**Dependencies"),
            "Verification Failed: Report missing dependencies section"
        );
        assert!(
            report.contains("## Code Context"),
            "Verification Failed: Report missing code context section"
        );
        assert!(
            report.contains("```typescript"),
            "Verification Failed: Report missing code blocks"
        );
        assert!(
            report.contains("import { greet }"),
            "Verification Failed: Report missing target file code"
        );
        assert!(
            report.contains("export const greet"),
            "Verification Failed: Report missing dependency file code"
        );
    }

    /// NIGHTMARE LEVEL STRESS TEST
    /// Tests all edge cases that break naive parsers:
    /// - Circular dependencies
    /// - Barrel re-exports
    /// - Renamed imports
    /// - Type-only imports
    /// - Dynamic imports
    /// - Deep relative paths
    #[test]
    fn test_nightmare_scenario() {
        let temp_dir = TempDir::new().expect("Failed to create temp directory");
        let root = temp_dir.path();

        // Create deep nested structure for deep relative path test
        // root/
        //   src/
        //     features/
        //       auth/
        //         components/
        //           LoginForm.tsx
        //     utils/
        //       helpers.ts
        //   types/
        //     user.ts
        //   components/
        //     Button.tsx
        //     index.ts (barrel)
        //   circular/
        //     A.ts
        //     B.ts
        //   lazy/
        //     loader.ts
        //     heavy-module.ts

        let src = root.join("src");
        let features = src.join("features");
        let auth = features.join("auth");
        let auth_components = auth.join("components");
        let utils = src.join("utils");
        let types = root.join("types");
        let components = root.join("components");
        let circular = root.join("circular");
        let lazy = root.join("lazy");

        // Create all directories
        for dir in &[&src, &features, &auth, &auth_components, &utils, &types, &components, &circular, &lazy] {
            fs::create_dir_all(dir).expect("Failed to create directory");
        }

        // ============================================
        // 1. CIRCULAR DEPENDENCY: A.ts <-> B.ts
        // ============================================
        let a_content = r#"import { funcB } from './B';

export const funcA = (): string => {
    return 'A calls ' + funcB();
};

export const standalone = () => 'standalone A';"#;
        write_file(&circular.join("A.ts"), a_content);

        let b_content = r#"import { standalone } from './A';

export const funcB = (): string => {
    return 'B uses ' + standalone();
};"#;
        write_file(&circular.join("B.ts"), b_content);

        // ============================================
        // 2. BARREL RE-EXPORTS: index.ts with export *
        // ============================================
        let button_content = r#"export const Button = () => '<button>Click me</button>';"#;
        write_file(&components.join("Button.tsx"), button_content);

        let barrel_content = r#"export * from './Button';
export { Button as DefaultButton } from './Button';"#;
        write_file(&components.join("index.ts"), barrel_content);

        // ============================================
        // 3. RENAMED IMPORTS: import { X as Y }
        // ============================================
        let helpers_content = r#"export const formatDate = (d: Date) => d.toISOString();
export const formatCurrency = (n: number) => `$${n.toFixed(2)}`;"#;
        write_file(&utils.join("helpers.ts"), helpers_content);

        // ============================================
        // 4. TYPE-ONLY IMPORTS: import type { X }
        // ============================================
        let user_type_content = r#"export interface User {
    id: string;
    name: string;
    email: string;
    createdAt: Date;
}

export type UserRole = 'admin' | 'user' | 'guest';"#;
        write_file(&types.join("user.ts"), user_type_content);

        // ============================================
        // 5. DYNAMIC IMPORTS: await import('./x')
        // ============================================
        let heavy_module_content = r#"export const heavyComputation = (data: number[]) => {
    return data.reduce((a, b) => a + b, 0);
};

export const anotherHeavyThing = () => 'heavy';"#;
        write_file(&lazy.join("heavy-module.ts"), heavy_module_content);

        let loader_content = r#"export const loadHeavyModule = async () => {
    const module = await import('./heavy-module');
    return module.heavyComputation([1, 2, 3]);
};

export const conditionalLoad = async (condition: boolean) => {
    if (condition) {
        const { anotherHeavyThing } = await import('./heavy-module');
        return anotherHeavyThing();
    }
    return null;
};"#;
        write_file(&lazy.join("loader.ts"), loader_content);

        // ============================================
        // 6. DEEP RELATIVE PATHS + ALL FEATURES COMBINED
        // ============================================
        let login_form_content = r#"import type { User, UserRole } from '../../../../types/user';
import { formatDate as formatUserDate } from '../../../utils/helpers';
import { Button } from '../../../../components';

interface LoginFormProps {
    onLogin: (user: User) => void;
    allowedRoles: UserRole[];
}

export const LoginForm = (props: LoginFormProps) => {
    const handleSubmit = () => {
        const user: User = {
            id: '1',
            name: 'Test',
            email: 'test@test.com',
            createdAt: new Date()
        };
        console.log(formatUserDate(user.createdAt));
        props.onLogin(user);
    };
    
    return Button() + '<form>Login</form>';
};"#;
        write_file(&auth_components.join("LoginForm.tsx"), login_form_content);

        // ============================================
        // RUN THE ANALYSIS
        // ============================================
        let files = find_typescript_files(root);
        let graph = build_dependency_graph(root, &files);
        let dep_map = graph_to_dependency_map(&graph, root);

        // Helper to find node by filename
        let find_node = |filename: &str| -> Option<NodeIndex> {
            for idx in graph.node_indices() {
                let path = &graph[idx];
                if path.to_string_lossy().replace('\\', "/").ends_with(filename) {
                    return Some(idx);
                }
            }
            None
        };

        // Helper to check if edge exists between files
        let has_edge = |from: &str, to: &str| -> bool {
            if let (Some(from_idx), Some(to_idx)) = (find_node(from), find_node(to)) {
                graph.contains_edge(from_idx, to_idx)
            } else {
                false
            }
        };

        // ============================================
        // ASSERTIONS - THE NIGHTMARE GAUNTLET
        // ============================================

        // 1. CIRCULAR DEPENDENCY TEST
        assert!(
            has_edge("circular/A.ts", "circular/B.ts"),
            "NIGHTMARE FAILED: Missing edge A.ts -> B.ts (circular dependency)"
        );
        assert!(
            has_edge("circular/B.ts", "circular/A.ts"),
            "NIGHTMARE FAILED: Missing edge B.ts -> A.ts (circular dependency)"
        );

        // 2. BARREL RE-EXPORT TEST
        assert!(
            has_edge("components/index.ts", "components/Button.tsx"),
            "NIGHTMARE FAILED: Barrel index.ts must link to Button.tsx via 'export * from'"
        );

        // 3. TYPE-ONLY IMPORT TEST (CRITICAL - types break builds!)
        assert!(
            has_edge("src/features/auth/components/LoginForm.tsx", "types/user.ts"),
            "NIGHTMARE FAILED: Type-only import 'import type {{ User }}' must be tracked!"
        );

        // 4. RENAMED IMPORT TEST
        assert!(
            has_edge("src/features/auth/components/LoginForm.tsx", "src/utils/helpers.ts"),
            "NIGHTMARE FAILED: Renamed import 'import {{ formatDate as formatUserDate }}' must be tracked!"
        );

        // 5. DYNAMIC IMPORT TEST
        assert!(
            has_edge("lazy/loader.ts", "lazy/heavy-module.ts"),
            "NIGHTMARE FAILED: Dynamic import 'await import(./heavy-module)' must be tracked!"
        );

        // 6. DEEP RELATIVE PATH TEST
        assert!(
            has_edge("src/features/auth/components/LoginForm.tsx", "components/index.ts"),
            "NIGHTMARE FAILED: Deep relative path '../../../../components' must resolve correctly!"
        );

        // 7. VERIFY GRAPH INTEGRITY - all files should be in the graph
        let expected_files = vec![
            "circular/A.ts",
            "circular/B.ts",
            "components/Button.tsx",
            "components/index.ts",
            "types/user.ts",
            "src/utils/helpers.ts",
            "lazy/loader.ts",
            "lazy/heavy-module.ts",
            "src/features/auth/components/LoginForm.tsx",
        ];

        for expected in &expected_files {
            assert!(
                find_node(expected).is_some(),
                "NIGHTMARE FAILED: File '{}' not found in graph!",
                expected
            );
        }

        // 8. VERIFY DEPENDENCY MAP HAS CORRECT STRUCTURE
        // LoginForm should have 3 dependencies: types/user.ts, utils/helpers.ts, components/index.ts
        let login_form_key = dep_map.dependencies.keys()
            .find(|k| k.contains("LoginForm"))
            .expect("NIGHTMARE FAILED: LoginForm.tsx not in dependency map");
        
        let login_deps = &dep_map.dependencies[login_form_key];
        assert!(
            login_deps.len() >= 3,
            "NIGHTMARE FAILED: LoginForm.tsx should have at least 3 dependencies, found {}",
            login_deps.len()
        );

        // 9. IMPACT ANALYSIS TEST - changing user.ts should impact LoginForm
        let user_idx = find_node("types/user.ts")
            .expect("NIGHTMARE FAILED: types/user.ts not found for impact test");
        let (direct, _indirect) = get_impact_chain(&graph, user_idx, root);
        
        let login_in_impact = direct.iter().any(|f| f.contains("LoginForm"));
        assert!(
            login_in_impact,
            "NIGHTMARE FAILED: Changing types/user.ts should impact LoginForm.tsx!"
        );

        // 10. CIRCULAR DEPENDENCY IMPACT - changing A should impact B and vice versa
        let a_idx = find_node("circular/A.ts")
            .expect("NIGHTMARE FAILED: circular/A.ts not found");
        let (a_direct, _) = get_impact_chain(&graph, a_idx, root);
        assert!(
            a_direct.iter().any(|f| f.contains("B.ts")),
            "NIGHTMARE FAILED: Changing A.ts should impact B.ts (circular)!"
        );

        let b_idx = find_node("circular/B.ts")
            .expect("NIGHTMARE FAILED: circular/B.ts not found");
        let (b_direct, _) = get_impact_chain(&graph, b_idx, root);
        assert!(
            b_direct.iter().any(|f| f.contains("A.ts")),
            "NIGHTMARE FAILED: Changing B.ts should impact A.ts (circular)!"
        );

        println!("🎉 NIGHTMARE SCENARIO PASSED - Parser is battle-tested!");
    }
}
